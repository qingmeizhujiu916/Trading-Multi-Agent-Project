#!/usr/bin/env python3
"""
安装项目依赖项
"""

import subprocess
import sys
import os

def check_python_version():
    """检查Python版本"""
    print("检查Python版本...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"错误: Python版本需要3.8+，当前版本: {version.major}.{version.minor}.{version.micro}")
        return False
    print(f"✓ Python版本: {version.major}.{version.minor}.{version.micro}")
    return True

def check_requirements():
    """检查requirements.txt文件"""
    print("\n检查requirements.txt文件...")
    requirements_file = "requirements.txt"
    if not os.path.exists(requirements_file):
        print(f"✗ 未找到{requirements_file}文件")
        return False
    
    with open(requirements_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        requirements = [line.strip() for line in lines if line.strip() and not line.startswith('#')]
    
    print(f"✓ 找到{len(requirements)}个依赖项")
    return True

def install_dependencies():
    """安装依赖项"""
    print("\n安装依赖项...")
    try:
        # 使用pip安装requirements.txt中的依赖
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
            capture_output=True,
            text=True,
            check=True
        )
        print("✓ 依赖项安装成功")
        return True
    except subprocess.CalledProcessError as e:
        print(f"✗ 依赖项安装失败:")
        print(f"错误输出: {e.stderr}")
        return False
    except Exception as e:
        print(f"✗ 安装过程中出现错误: {e}")
        return False

def verify_installation():
    """验证安装"""
    print("\n验证安装...")
    
    # 检查核心依赖
    dependencies = [
        ("fastapi", "FastAPI"),
        ("uvicorn", "Uvicorn"),
        ("pydantic", "Pydantic"),
        ("pandas", "Pandas"),
        ("numpy", "NumPy"),
    ]
    
    all_installed = True
    for module_name, display_name in dependencies:
        try:
            __import__(module_name)
            print(f"✓ {display_name} 已安装")
        except ImportError:
            print(f"✗ {display_name} 未安装")
            all_installed = False
    
    return all_installed

def create_venv_instructions():
    """创建虚拟环境使用说明"""
    print("\n" + "="*60)
    print("虚拟环境使用说明:")
    print("="*60)
    print("""
推荐使用虚拟环境来管理项目依赖:

1. 创建虚拟环境:
   python -m venv venv

2. 激活虚拟环境:
   - Windows: venv\\Scripts\\activate
   - macOS/Linux: source venv/bin/activate

3. 安装依赖:
   pip install -r requirements.txt

4. 运行项目:
   python main.py
    """)

def main():
    """主函数"""
    print("="*60)
    print("多智能体股市监测系统 - 依赖项安装")
    print("="*60)
    
    # 检查Python版本
    if not check_python_version():
        return False
    
    # 检查requirements.txt
    if not check_requirements():
        return False
    
    # 询问是否安装依赖
    response = input("\n是否要安装依赖项? (y/n): ").strip().lower()
    if response != 'y':
        print("跳过依赖项安装")
        create_venv_instructions()
        return True
    
    # 安装依赖
    if not install_dependencies():
        return False
    
    # 验证安装
    if not verify_installation():
        print("\n部分依赖项未安装成功，请手动安装:")
        print("pip install -r requirements.txt")
        return False
    
    print("\n" + "="*60)
    print("依赖项安装完成!")
    print("="*60)
    print("\n现在可以运行项目:")
    print("python main.py")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)