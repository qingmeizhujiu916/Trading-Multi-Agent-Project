#!/usr/bin/env python3
"""
数据获取工具 - 从公开API获取真实的股票数据
支持Yahoo Finance, Alpha Vantage等数据源
"""

import json
import requests
import pandas as pd
from datetime import datetime, timedelta
import time
import os
from pathlib import Path
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class StockDataFetcher:
    """股票数据获取器"""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        # 公开API配置（免费层）
        self.yahoo_finance_base = "https://query1.finance.yahoo.com/v8/finance/chart/"
        self.alpha_vantage_key = None  # 需要注册获取API密钥
        
        # 公司列表
        self.companies = [
            {"ticker": "AAPL", "name": "Apple Inc.", "sector": "Technology"},
            {"ticker": "TSLA", "name": "Tesla Inc.", "sector": "Consumer Discretionary"},
            {"ticker": "BABA", "name": "Alibaba Group Holding Limited", "sector": "Consumer Discretionary"},
            {"ticker": "MSFT", "name": "Microsoft Corporation", "sector": "Technology"},
            {"ticker": "GOOGL", "name": "Alphabet Inc.", "sector": "Communication Services"},
            {"ticker": "AMZN", "name": "Amazon.com Inc.", "sector": "Consumer Discretionary"},
            {"ticker": "NVDA", "name": "NVIDIA Corporation", "sector": "Technology"},
            {"ticker": "META", "name": "Meta Platforms Inc.", "sector": "Communication Services"},
            {"ticker": "JPM", "name": "JPMorgan Chase & Co.", "sector": "Financial Services"},
            {"ticker": "V", "name": "Visa Inc.", "sector": "Financial Services"}
        ]
    
    def fetch_price_data_yahoo(self, ticker: str, period: str = "1mo", interval: str = "1d") -> list:
        """从Yahoo Finance获取价格数据"""
        url = f"{self.yahoo_finance_base}{ticker}"
        params = {
            "range": period,
            "interval": interval,
            "includePrePost": "false"
        }
        
        try:
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                
                # 解析Yahoo Finance数据
                chart_data = data.get("chart", {}).get("result", [{}])[0]
                timestamps = chart_data.get("timestamp", [])
                quotes = chart_data.get("indicators", {}).get("quote", [{}])[0]
                
                price_history = []
                for i in range(len(timestamps)):
                    if i < len(quotes.get("open", [])):
                        price_history.append({
                            "date": datetime.fromtimestamp(timestamps[i]).strftime("%Y-%m-%d"),
                            "open": quotes["open"][i] if quotes["open"][i] else 0,
                            "high": quotes["high"][i] if quotes["high"][i] else 0,
                            "low": quotes["low"][i] if quotes["low"][i] else 0,
                            "close": quotes["close"][i] if quotes["close"][i] else 0,
                            "volume": quotes["volume"][i] if quotes["volume"][i] else 0
                        })
                
                logger.info(f"成功获取 {ticker} 的价格数据: {len(price_history)} 条记录")
                return price_history
            else:
                logger.warning(f"Yahoo Finance API请求失败: {response.status_code}")
                return self._generate_sample_price_data(ticker)
                
        except Exception as e:
            logger.error(f"获取 {ticker} 价格数据失败: {e}")
            return self._generate_sample_price_data(ticker)
    
    def _generate_sample_price_data(self, ticker: str) -> list:
        """生成示例价格数据（当API失败时使用）"""
        logger.info(f"为 {ticker} 生成示例价格数据")
        
        # 基于股票代码生成不同的基础价格
        base_prices = {
            "AAPL": 180.0,
            "TSLA": 200.0,
            "BABA": 90.0,
            "MSFT": 400.0,
            "GOOGL": 150.0,
            "AMZN": 170.0,
            "NVDA": 800.0,
            "META": 500.0,
            "JPM": 180.0,
            "V": 270.0
        }
        
        base_price = base_prices.get(ticker, 100.0)
        price_history = []
        
        # 生成30天的价格数据
        today = datetime.now()
        for i in range(30, 0, -1):
            date = today - timedelta(days=i)
            
            # 模拟价格波动
            volatility = 0.02  # 2%的日波动率
            change = base_price * volatility * (0.5 - (i % 10) / 20)
            price = base_price + change
            
            price_history.append({
                "date": date.strftime("%Y-%m-%d"),
                "open": price * 0.995,
                "high": price * 1.01,
                "low": price * 0.99,
                "close": price,
                "volume": int(10000000 * (0.8 + 0.4 * (i % 7) / 7))
            })
            
            # 更新基础价格用于下一天
            base_price = price
        
        return price_history
    
    def fetch_financial_data(self, ticker: str) -> dict:
        """获取财务数据（模拟真实数据）"""
        # 注意：真实财务数据需要付费API或从财报中提取
        # 这里提供基于真实数据的模拟
        
        financial_templates = {
            "AAPL": {
                "revenue": 383285000000,
                "gross_profit": 169148000000,
                "net_income": 96995000000,
                "total_assets": 352583000000,
                "total_liabilities": 279414000000,
                "equity": 73169000000,
                "current_assets": 143566000000,
                "current_liabilities": 145308000000,
                "inventory": 6232000000,
                "operating_cash_flow": 110543000000,
                "pe_ratio": 28.5,
                "pb_ratio": 38.2
            },
            "TSLA": {
                "revenue": 96773000000,
                "gross_profit": 17600000000,
                "net_income": 14974000000,
                "total_assets": 106618000000,
                "total_liabilities": 43474000000,
                "equity": 63144000000,
                "current_assets": 40222000000,
                "current_liabilities": 28774000000,
                "inventory": 13626000000,
                "operating_cash_flow": 13256000000,
                "pe_ratio": 42.3,
                "pb_ratio": 8.7
            },
            "BABA": {
                "revenue": 868687000000,
                "gross_profit": 350000000000,
                "net_income": 72500000000,
                "total_assets": 1760000000000,
                "total_liabilities": 650000000000,
                "equity": 1110000000000,
                "current_assets": 550000000000,
                "current_liabilities": 320000000000,
                "inventory": 45000000000,
                "operating_cash_flow": 180000000000,
                "pe_ratio": 15.2,
                "pb_ratio": 1.8
            }
        }
        
        # 如果找不到模板，生成合理的模拟数据
        if ticker not in financial_templates:
            logger.info(f"为 {ticker} 生成模拟财务数据")
            
            # 基于市值估算
            market_caps = {
                "MSFT": 3000000000000,
                "GOOGL": 1800000000000,
                "AMZN": 1800000000000,
                "NVDA": 2000000000000,
                "META": 1200000000000,
                "JPM": 500000000000,
                "V": 500000000000
            }
            
            market_cap = market_caps.get(ticker, 1000000000000)
            
            # 生成合理的财务比率
            revenue = market_cap * 0.3  # 营收约为市值的30%
            net_margin = 0.15  # 15%的净利率
            net_income = revenue * net_margin
            
            return {
                "revenue": int(revenue),
                "gross_profit": int(revenue * 0.4),  # 40%的毛利率
                "net_income": int(net_income),
                "total_assets": int(market_cap * 1.2),  # 总资产约为市值的1.2倍
                "total_liabilities": int(market_cap * 0.6),  # 负债约为市值的0.6倍
                "equity": int(market_cap * 0.6),  # 权益约为市值的0.6倍
                "current_assets": int(market_cap * 0.3),  # 流动资产约为市值的0.3倍
                "current_liabilities": int(market_cap * 0.2),  # 流动负债约为市值的0.2倍
                "inventory": int(market_cap * 0.05),  # 存货约为市值的5%
                "operating_cash_flow": int(net_income * 1.2),  # 经营现金流约为净利润的1.2倍
                "pe_ratio": 25.0,  # 市盈率25
                "pb_ratio": 5.0  # 市净率5
            }
        
        return financial_templates[ticker]
    
    def fetch_market_overview(self) -> dict:
        """获取市场概况数据"""
        # 模拟市场数据
        today = datetime.now()
        
        return {
            "timestamp": today.isoformat(),
            "market_overview": {
                "market_condition": "neutral",
                "risk_level": "medium",
                "major_indices": {
                    "sp500": {
                        "value": 5200.45,
                        "change": 15.32,
                        "change_percent": 0.30,
                        "trend": "up"
                    },
                    "nasdaq": {
                        "value": 16250.78,
                        "change": 45.21,
                        "change_percent": 0.28,
                        "trend": "up"
                    },
                    "dow_jones": {
                        "value": 39500.12,
                        "change": 120.45,
                        "change_percent": 0.31,
                        "trend": "up"
                    }
                },
                "economic_indicators": {
                    "gdp_growth": 2.3,
                    "inflation_rate": 2.8,
                    "unemployment_rate": 3.9,
                    "interest_rate": 5.25
                },
                "sector_performance": {
                    "technology": "outperforming",
                    "healthcare": "neutral",
                    "financials": "underperforming",
                    "energy": "outperforming",
                    "consumer_discretionary": "neutral"
                },
                "market_sentiment": {
                    "fear_greed_index": 55,
                    "vix_index": 15.2,
                    "put_call_ratio": 0.85
                }
            }
        }
    
    def update_all_data(self, use_real_api: bool = True):
        """更新所有数据"""
        logger.info("开始更新所有数据...")
        
        # 1. 更新价格历史数据
        price_data = {"last_updated": datetime.now().strftime("%Y-%m-%d"), "companies": []}
        
        for company in self.companies:
            ticker = company["ticker"]
            logger.info(f"获取 {ticker} 的价格数据...")
            
            if use_real_api:
                price_history = self.fetch_price_data_yahoo(ticker)
            else:
                price_history = self._generate_sample_price_data(ticker)
            
            price_data["companies"].append({
                "ticker": ticker,
                "name": company["name"],
                "price_history": price_history
            })
            
            # 避免API速率限制
            time.sleep(1)
        
        # 保存价格数据
        price_file = self.data_dir / "price_history.json"
        with open(price_file, 'w', encoding='utf-8') as f:
            json.dump(price_data, f, indent=2, ensure_ascii=False)
        logger.info(f"价格数据已保存到: {price_file}")
        
        # 2. 更新公司财务数据
        financial_data = {"last_updated": datetime.now().strftime("%Y-%m-%d"), "companies": []}
        
        for company in self.companies:
            ticker = company["ticker"]
            logger.info(f"获取 {ticker} 的财务数据...")
            
            financials = self.fetch_financial_data(ticker)
            
            # 计算关键指标
            market_cap = financials.get("revenue", 0) * 3  # 简化的市值估算
            pe_ratio = financials.get("pe_ratio", 25.0)
            
            financial_data["companies"].append({
                "ticker": ticker,
                "name": company["name"],
                "sector": company["sector"],
                "industry": self._get_industry(company["sector"]),
                "financials": financials,
                "key_metrics": {
                    "market_cap": int(market_cap),
                    "dividend_yield": 0.5 if ticker in ["AAPL", "JPM", "V"] else 0.0,
                    "beta": 1.0 if ticker in ["AAPL", "MSFT"] else 1.5
                }
            })
        
        # 保存财务数据
        financial_file = self.data_dir / "company_financials.json"
        with open(financial_file, 'w', encoding='utf-8') as f:
            json.dump(financial_data, f, indent=2, ensure_ascii=False)
        logger.info(f"财务数据已保存到: {financial_file}")
        
        # 3. 更新市场概况数据
        market_data = self.fetch_market_overview()
        market_file = self.data_dir / "market_overview.json"
        with open(market_file, 'w', encoding='utf-8') as f:
            json.dump(market_data, f, indent=2, ensure_ascii=False)
        logger.info(f"市场概况数据已保存到: {market_file}")
        
        logger.info("所有数据更新完成！")
    
    def _get_industry(self, sector: str) -> str:
        """根据行业获取具体的产业"""
        industries = {
            "Technology": ["Software", "Hardware", "Semiconductors", "Internet"],
            "Consumer Discretionary": ["Automotive", "Retail", "Entertainment", "Travel"],
            "Communication Services": ["Social Media", "Telecom", "Media", "Entertainment"],
            "Financial Services": ["Banking", "Insurance", "Investment", "Fintech"],
            "Healthcare": ["Pharmaceuticals", "Biotech", "Medical Devices", "Healthcare Services"],
            "Energy": ["Oil & Gas", "Renewable Energy", "Utilities"],
            "Industrials": ["Manufacturing", "Transportation", "Construction"],
            "Consumer Staples": ["Food & Beverage", "Household Products", "Personal Products"]
        }
        
        if sector in industries:
            return industries[sector][0]
        return "General"
    
    def create_test_data(self):
        """创建测试数据（小数据集）"""
        logger.info("创建测试数据集...")
        
        # 只使用前3家公司进行测试
        test_companies = self.companies[:3]
        
        # 更新价格数据
        price_data = {"last_updated": datetime.now().strftime("%Y-%m-%d"), "companies": []}
        
        for company in test_companies:
            ticker = company["ticker"]
            price_history = self._generate_sample_price_data(ticker)
            
            price_data["companies"].append({
                "ticker": ticker,
                "name": company["name"],
                "price_history": price_history[:15]  # 只保留15天数据
            })
        
        price_file = self.data_dir / "price_history_test.json"
        with open(price_file, 'w', encoding='utf-8') as f:
            json.dump(price_data, f, indent=2, ensure_ascii=False)
        
        # 更新财务数据
        financial_data = {"last_updated": datetime.now().strftime("%Y-%m-%d"), "companies": []}
        
        for company in test_companies:
            ticker = company["ticker"]
            financials = self.fetch_financial_data(ticker)
            
            financial_data["companies"].append({
                "ticker": ticker,
                "name": company["name"],
                "sector": company["sector"],
                "industry": self._get_industry(company["sector"]),
                "financials": financials,
                "key_metrics": {
                    "market_cap": int(financials.get("revenue", 0) * 3),
                    "dividend_yield": 0.5 if ticker in ["AAPL", "JPM", "V"] else 0.0,
                    "beta": 1.0 if ticker in ["AAPL", "MSFT"] else 1.5
                }
            })
        
        financial_file = self.data_dir / "company_financials_test.json"
        with open(financial_file, 'w', encoding='utf-8') as f:
            json.dump(financial_data, f, indent=2, ensure_ascii=False)
        
        # 更新市场概况数据
        market_data = self.fetch_market_overview()
        market_file = self.data_dir / "market_overview_test.json"
        with open(market_file, 'w', encoding='utf-8') as f:
            json.dump(market_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"测试数据已保存到: {price_file}, {financial_file}, {market_file}")

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="股票数据获取工具")
    parser.add_argument("--mode", choices=["full", "test", "update"], default="test",
                       help="运行模式: full(完整数据), test(测试数据), update(更新现有数据)")
    parser.add_argument("--real-api", action="store_true",
                       help="使用真实API获取数据（需要网络连接）")
    parser.add_argument("--companies", nargs="+",
                       help="指定要获取数据的公司代码")
    
    args = parser.parse_args()
    
    fetcher = StockDataFetcher()
    
    if args.companies:
        # 只获取指定公司的数据
        fetcher.companies = [c for c in fetcher.companies if c["ticker"] in args.companies]
    
    if args.mode == "full":
        print("获取完整数据集...")
        fetcher.update_all_data(use_real_api=args.real_api)
    elif args.mode == "test":
        print("创建测试数据集...")
        fetcher.create_test_data()
    elif args.mode == "update":
        print("更新现有数据...")
        # 这里可以添加更新逻辑，比如只更新最近的数据
        fetcher.update_all_data(use_real_api=args.real_api)
    
    print("数据获取完成！")

if __name__ == "__main__":
    main()
