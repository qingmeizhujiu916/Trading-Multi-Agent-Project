# 多智能体股市监测系统 - 前后端整合指南

## 🏗️ 系统架构概述

### 整体架构
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   前端应用      │    │   后端API       │    │   OpenClaw      │
│   (React)       │◄──►│   (FastAPI)     │◄──►│   智能体框架    │
│                 │    │                 │    │                 │
│  • 仪表板       │    │  • REST API     │    │  • Orchestrator │
│  • 分析页面     │    │  • WebSocket    │    │  • Macro Agent  │
│  • 报告中心     │    │  • 数据缓存     │    │  • Research     │
│  • 设置中心     │    │  • 认证授权     │    │  • Trading      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   浏览器        │    │   数据库        │    │   本地数据      │
│   (Chrome)      │    │   (PostgreSQL)  │    │   (JSON文件)    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🔌 API接口设计

### 1. 核心API端点

#### 市场数据API
```http
GET    /api/market/overview           # 获取市场概览
GET    /api/market/indices            # 获取指数数据
GET    /api/market/sectors            # 获取行业表现
GET    /api/market/sentiment          # 获取市场情绪
```

#### 智能体API
```http
GET    /api/agents/status             # 获取智能体状态
POST   /api/agents/start              # 启动智能体分析
GET    /api/agents/{id}/progress      # 获取分析进度
POST   /api/agents/{id}/stop          # 停止智能体
```

#### 分析API
```http
POST   /api/analysis/single           # 单公司分析
POST   /api/analysis/batch            # 批量分析
GET    /api/analysis/{id}/result      # 获取分析结果
GET    /api/analysis/history          # 获取分析历史
```

#### 报告API
```http
GET    /api/reports                   # 获取报告列表
GET    /api/reports/{id}              # 获取报告详情
POST   /api/reports/generate          # 生成报告
POST   /api/reports/export/{format}   # 导出报告
```

#### 用户API
```http
POST   /api/auth/login                # 用户登录
POST   /api/auth/register             # 用户注册
GET    /api/user/profile              # 获取用户信息
PUT    /api/user/preferences          # 更新用户偏好
```

### 2. WebSocket接口

#### 实时数据推送
```javascript
// 连接WebSocket
const ws = new WebSocket('ws://localhost:8000/ws');

// 订阅市场数据
ws.send(JSON.stringify({
  type: 'subscribe',
  channel: 'market_data'
}));

// 订阅智能体状态
ws.send(JSON.stringify({
  type: 'subscribe', 
  channel: 'agent_status'
}));

// 接收消息
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  switch(data.channel) {
    case 'market_data':
      updateMarketData(data.payload);
      break;
    case 'agent_status':
      updateAgentStatus(data.payload);
      break;
    case 'analysis_progress':
      updateAnalysisProgress(data.payload);
      break;
  }
};
```

## 🛠️ 后端实现

### 1. FastAPI应用结构

```python
# main.py
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn

from api.routers import market, agents, analysis, reports, auth
from core.websocket_manager import ConnectionManager
from core.data_loader import DataLoader

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动时初始化
    app.state.data_loader = DataLoader()
    app.state.ws_manager = ConnectionManager()
    yield
    # 关闭时清理
    await app.state.data_loader.close()

app = FastAPI(title="多智能体股市监测系统", lifespan=lifespan)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(market.router, prefix="/api/market", tags=["市场数据"])
app.include_router(agents.router, prefix="/api/agents", tags=["智能体"])
app.include_router(analysis.router, prefix="/api/analysis", tags=["分析"])
app.include_router(reports.router, prefix="/api/reports", tags=["报告"])
app.include_router(auth.router, prefix="/api/auth", tags=["认证"])

# WebSocket端点
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await app.state.ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            await handle_websocket_message(data, websocket)
    except WebSocketDisconnect:
        app.state.ws_manager.disconnect(websocket)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
```

### 2. 智能体服务集成

```python
# services/agent_service.py
import asyncio
import json
from typing import Dict, List, Optional
from pathlib import Path

class AgentService:
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.agents = self._load_agents()
        
    def _load_agents(self) -> Dict:
        """加载智能体配置"""
        agents_config = {}
        agents_dir = Path("agents")
        
        for agent_dir in agents_dir.iterdir():
            if agent_dir.is_dir():
                agent_file = agent_dir / "agent.md"
                if agent_file.exists():
                    with open(agent_file, 'r', encoding='utf-8') as f:
                        # 解析agent.md文件
                        content = f.read()
                        agents_config[agent_dir.name] = self._parse_agent_config(content)
        
        return agents_config
    
    async def start_analysis(self, ticker: str, analysis_type: str = "full") -> Dict:
        """启动分析流程"""
        # 1. 准备数据
        market_data = self._load_market_data()
        company_data = self._load_company_data(ticker)
        price_data = self._load_price_data(ticker)
        
        # 2. 执行智能体工作流
        results = {}
        
        if analysis_type == "full":
            # 完整分析流程
            results["macro"] = await self._run_macro_agent(market_data, ticker)
            results["research"] = await self._run_research_agent(company_data)
            results["trading"] = await self._run_trading_agent(price_data)
            results["executor"] = await self._run_executor_agent(results)
        elif analysis_type == "quick":
            # 快速分析流程
            results["research"] = await self._run_research_agent(company_data)
            results["trading"] = await self._run_trading_agent(price_data)
        
        # 3. 整合结果
        integrated_result = self._integrate_results(results)
        
        return integrated_result
    
    def _load_market_data(self) -> Dict:
        """加载市场数据"""
        market_file = self.data_dir / "market_overview.json"
        with open(market_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def _load_company_data(self, ticker: str) -> Optional[Dict]:
        """加载公司数据"""
        financials_file = self.data_dir / "company_financials.json"
        with open(financials_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            for company in data.get("companies", []):
                if company.get("ticker") == ticker:
                    return company
        return None
    
    def _load_price_data(self, ticker: str) -> Optional[List[Dict]]:
        """加载价格数据"""
        price_file = self.data_dir / "price_history.json"
        with open(price_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            for company in data.get("companies", []):
                if company.get("ticker") == ticker:
                    return company.get("price_history", [])
        return None
```

## 🔗 前端集成

### 1. API服务封装

```typescript
// src/services/api.ts
import axios, { AxiosInstance, AxiosResponse } from 'axios';

class ApiService {
  private client: AxiosInstance;
  private ws: WebSocket | null = null;
  private wsCallbacks: Map<string, Function[]> = new Map();

  constructor() {
    this.client = axios.create({
      baseURL: 'http://localhost:8000/api',
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // 请求拦截器
    this.client.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // 响应拦截器
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // 处理认证错误
          localStorage.removeItem('token');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // 市场数据API
  async getMarketOverview() {
    return this.client.get('/market/overview');
  }

  async getMarketIndices() {
    return this.client.get('/market/indices');
  }

  // 智能体API
  async getAgentStatus() {
    return this.client.get('/agents/status');
  }

  async startAnalysis(ticker: string, analysisType: string = 'full') {
    return this.client.post('/analysis/single', {
      ticker,
      analysis_type: analysisType,
    });
  }

  async getAnalysisResult(analysisId: string) {
    return this.client.get(`/analysis/${analysisId}/result`);
  }

  // 报告API
  async getReports() {
    return this.client.get('/reports');
  }

  async generateReport(analysisId: string) {
    return this.client.post('/reports/generate', { analysis_id: analysisId });
  }

  // WebSocket连接
  connectWebSocket() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      return;
    }

    this.ws = new WebSocket('ws://localhost:8000/ws');

    this.ws.onopen = () => {
      console.log('WebSocket连接已建立');
      this.subscribe('market_data');
      this.subscribe('agent_status');
    };

    this.ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        this.notifyCallbacks(data.channel, data.payload);
      } catch (error) {
        console.error('WebSocket消息解析错误:', error);
      }
    };

    this.ws.onclose = () => {
      console.log('WebSocket连接已关闭');
      setTimeout(() => this.connectWebSocket(), 5000);
    };
  }

  subscribe(channel: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'subscribe',
        channel,
      }));
    }
  }

  on(channel: string, callback: Function) {
    if (!this.wsCallbacks.has(channel)) {
      this.wsCallbacks.set(channel, []);
    }
    this.wsCallbacks.get(channel)!.push(callback);
  }

  private notifyCallbacks(channel: string, data: any) {
    const callbacks = this.wsCallbacks.get(channel);
    if (callbacks) {
      callbacks.forEach(callback => callback(data));
    }
  }
}

export const api = new ApiService();
```

### 2. 状态管理集成

```typescript
// src/stores/marketStore.ts
import { create } from 'zustand';
import { api } from '../services/api';

interface MarketData {
  indices: any[];
  sectors: any[];
  sentiment: any;
  lastUpdated: string;
}

interface MarketStore {
  data: MarketData;
  loading: boolean;
  error: string | null;
  
  fetchMarketData: () => Promise<void>;
  subscribeToMarketUpdates: () => void;
  setData: (data: Partial<MarketData>) => void;
}

export const useMarketStore = create<MarketStore>((set, get) => ({
  data: {
    indices: [],
    sectors: [],
    sentiment: {},
    lastUpdated: '',
  },
  loading: false,
  error: null,

  fetchMarketData: async () => {
    set({ loading: true, error: null });
    try {
      const [indicesRes, sectorsRes, sentimentRes] = await Promise.all([
        api.getMarketIndices(),
        api.getMarketOverview(),
        api.getMarketSentiment(),
      ]);

      set({
        data: {
          indices: indicesRes.data,
          sectors: sectorsRes.data.sectors,
          sentiment: sentimentRes.data,
          lastUpdated: new Date().toISOString(),
        },
        loading: false,
      });
    } catch (error: any) {
      set({ 
        error: error.message || '获取市场数据失败',
        loading: false 
      });
    }
  },

  subscribeToMarketUpdates: () => {
    api.on('market_data', (data: any) => {
      set(state => ({
        data: {
          ...state.data,
          ...data,
          lastUpdated: new Date().toISOString(),
        },
      }));
    });
  },

  setData: (data) => {
    set(state => ({
      data: { ...state.data, ...data },
    }));
  },
}));
```

### 3. 组件集成示例

```typescript
// src/components/dashboard/MarketOverview.tsx
import React, { useEffect } from 'react';
import { useMarketStore } from '../../stores/marketStore';
import { TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import MarketChart from '../charts/MarketChart';

const MarketOverview: React.FC = () => {
  const { data, loading, error, fetchMarketData, subscribeToMarketUpdates } = useMarketStore();

  useEffect(() => {
    fetchMarketData();
    subscribeToMarketUpdates();
    
    // 每30秒刷新数据
    const interval = setInterval(fetchMarketData, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-blue-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
        <p className="text-red-400">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 指数概览 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {data.indices.map((index) => (
          <div key={index.id} className="bg-gray-800/50 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-white">{index.name}</h4>
                <p className="text-2xl font-bold mt-2">${index.value.toFixed(2)}</p>
              </div>
              <div className={`flex items-center ${index.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {index.change >= 0 ? (
                  <TrendingUp className="w-5 h-5 mr-1" />
                ) : (
                  <TrendingDown className="w-5 h-5 mr-1" />
                )}
                <span>{index.change >= 0 ? '+' : ''}{index.change.toFixed(2)}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 市场图表 */}
      <MarketChart 
        data={data.indices.map(idx => ({
          time: idx.timestamp,
          value: idx.value,
          change: idx.change,
        }))}
        title="主要指数走势"
        color="#3b82f6"
      />

      {/* 行业表现 */}
      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4">行业表现</h3>
        <div className="space-y-3">
          {data.sectors.map((sector) => (
            <div key={sector.id} className="flex items-center justify-between">
              <span className="text