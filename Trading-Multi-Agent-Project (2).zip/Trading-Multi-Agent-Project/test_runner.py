#!/usr/bin/env python3
"""
测试运行器 - 用于自动化测试多智能体股市监测系统
"""

import asyncio
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from main import Orchestrator, DataLoader

async def test_data_loader():
    """测试数据加载器"""
    print("测试数据加载器...")
    data_loader = DataLoader()
    
    # 测试市场数据加载
    market_data = data_loader.load_market_data()
    print(f"✓ 市场数据加载成功: {market_data.get('timestamp', 'N/A')}")
    
    # 测试公司数据加载
    test_tickers = ["AAPL", "TSLA", "BABA"]
    for ticker in test_tickers:
        company_data = data_loader.load_company_data(ticker)
        if company_data:
            print(f"✓ {ticker} 公司数据加载成功")
        else:
            print(f"✗ {ticker} 公司数据加载失败")
    
    # 测试价格数据加载
    for ticker in test_tickers:
        price_data = data_loader.load_price_data(ticker)
        if price_data:
            print(f"✓ {ticker} 价格数据加载成功 ({len(price_data)} 条记录)")
        else:
            print(f"✗ {ticker} 价格数据加载失败")
    
    return True

async def test_agents():
    """测试智能体"""
    print("\n测试智能体...")
    data_loader = DataLoader()
    
    # 测试宏观智能体
    from main import MacroAgent
    macro_agent = MacroAgent(data_loader)
    macro_result = await macro_agent.analyze("AAPL")
    print(f"✓ 宏观智能体测试完成: {macro_result.get('recommendation', 'N/A')}")
    
    # 测试研究智能体
    from main import ResearchAgent
    research_agent = ResearchAgent(data_loader)
    research_result = await research_agent.analyze("AAPL")
    print(f"✓ 研究智能体测试完成: {research_result.get('recommendation', 'N/A')}")
    
    # 测试交易智能体
    from main import TradingAgent
    trading_agent = TradingAgent(data_loader)
    trading_result = await trading_agent.analyze("AAPL")
    print(f"✓ 交易智能体测试完成: {trading_result.get('trading_recommendation', 'N/A')}")
    
    # 测试执行监控智能体
    from main import ExecutorAgent
    executor_agent = ExecutorAgent()
    executor_result = await executor_agent.analyze(macro_result, research_result, trading_result)
    print(f"✓ 执行监控智能体测试完成: {executor_result.get('risk_assessment', {}).get('risk_level', 'N/A')}")
    
    return True

async def test_orchestrator():
    """测试总指挥智能体"""
    print("\n测试总指挥智能体...")
    orchestrator = Orchestrator()
    
    # 测试完整分析
    print("测试完整分析...")
    full_result = await orchestrator.analyze_company("AAPL", "full")
    if "error" not in full_result:
        print(f"✓ 完整分析成功:")
        print(f"  综合评分: {full_result.get('overall_score', 0):.1f}")
        print(f"  风险等级: {full_result.get('risk_level', 'N/A')}")
        print(f"  摘要: {full_result.get('summary', 'N/A')}")
    else:
        print(f"✗ 完整分析失败: {full_result.get('error', '未知错误')}")
    
    # 测试快速分析
    print("\n测试快速分析...")
    quick_result = await orchestrator.analyze_company("TSLA", "quick")
    if "error" not in quick_result:
        print(f"✓ 快速分析成功:")
        print(f"  综合评分: {quick_result.get('overall_score', 0):.1f}")
        print(f"  风险等级: {quick_result.get('risk_level', 'N/A')}")
    else:
        print(f"✗ 快速分析失败: {quick_result.get('error', '未知错误')}")
    
    return True

async def test_error_handling():
    """测试错误处理"""
    print("\n测试错误处理...")
    orchestrator = Orchestrator()
    
    # 测试无效股票代码
    invalid_result = await orchestrator.analyze_company("INVALID", "full")
    if "error" in invalid_result:
        print(f"✓ 无效股票代码处理成功: {invalid_result.get('error', 'N/A')}")
    else:
        print(f"✗ 无效股票代码处理失败")
    
    # 测试无效分析类型
    invalid_type_result = await orchestrator.analyze_company("AAPL", "invalid_type")
    if "error" in invalid_type_result:
        print(f"✓ 无效分析类型处理成功: {invalid_type_result.get('error', 'N/A')}")
    else:
        print(f"✗ 无效分析类型处理失败")
    
    return True

async def main():
    """主测试函数"""
    print("=" * 60)
    print("多智能体股市监测系统 - 自动化测试")
    print("=" * 60)
    
    try:
        # 创建日志目录
        import pathlib
        logs_dir = pathlib.Path("logs")
        logs_dir.mkdir(exist_ok=True)
        
        # 运行测试
        await test_data_loader()
        await test_agents()
        await test_orchestrator()
        await test_error_handling()
        
        print("\n" + "=" * 60)
        print("所有测试完成！")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)