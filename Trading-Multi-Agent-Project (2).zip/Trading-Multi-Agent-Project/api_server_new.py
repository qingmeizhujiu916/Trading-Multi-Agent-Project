#!/usr/bin/env python3
"""
多智能体股市监测系统 - API服务器
简化版本，修复语法错误
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import aiohttp
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/api_server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# DeepSeek API配置
DEEPSEEK_API_KEY = "sk-4e12ef8835d94ee0bfb79097eb9481d1"
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"

# 数据模型
class AnalysisRequest(BaseModel):
    ticker: str = Field(..., description="股票代码")
    analysis_type: str = Field("full", description="分析类型: full(完整分析)或quick(快速分析)")
    use_ai: bool = Field(True, description="是否使用AI分析")

class AnalysisResponse(BaseModel):
    ticker: str
    analysis_type: str
    timestamp: str
    overall_score: float
    risk_level: str
    summary: str
    recommendations: List[str]
    detailed_analysis: Dict[str, Any]
    metadata: Dict[str, Any]

class SystemStatus(BaseModel):
    status: str
    agents: List[str]
    api_available: bool
    timestamp: str

# 数据加载器
class DataLoader:
    """数据加载器 - 从本地JSON文件加载数据"""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
    def load_market_data(self) -> Dict:
        """加载市场宏观数据"""
        market_file = self.data_dir / "market_overview.json"
        if not market_file.exists():
            logger.warning(f"市场数据文件不存在: {market_file}")
            return self._create_sample_market_data()
        
        try:
            with open(market_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载市场数据失败: {e}")
            return self._create_sample_market_data()
    
    def load_company_data(self, ticker: str) -> Optional[Dict]:
        """加载公司财务数据"""
        financials_file = self.data_dir / "company_financials.json"
        if not financials_file.exists():
            logger.warning(f"财务数据文件不存在: {financials_file}")
            return None
        
        try:
            with open(financials_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for company in data.get("companies", []):
                    if company.get("ticker") == ticker:
                        return company
        except Exception as e:
            logger.error(f"加载财务数据失败: {e}")
        
        return None
    
    def load_price_data(self, ticker: str) -> Optional[List[Dict]]:
        """加载价格历史数据"""
        price_file = self.data_dir / "price_history.json"
        if not price_file.exists():
            logger.warning(f"价格数据文件不存在: {price_file}")
            return None
        
        try:
            with open(price_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for company in data.get("companies", []):
                    if company.get("ticker") == ticker:
                        return company.get("price_history", [])
        except Exception as e:
            logger.error(f"加载价格数据失败: {e}")
        
        return None
    
    def _create_sample_market_data(self) -> Dict:
        """创建示例市场数据"""
        return {
            "timestamp": datetime.now().isoformat(),
            "market_overview": {
                "market_condition": "neutral",
                "risk_level": "medium",
                "major_indices": {
                    "sp500": {"value": 5200.45, "change": 15.32},
                    "nasdaq": {"value": 16250.78, "change": 45.21},
                    "dow_jones": {"value": 39500.12, "change": 120.45}
                }
            }
        }

# DeepSeek AI集成
class DeepSeekAI:
    """DeepSeek AI集成类"""
    
    def __init__(self, api_key: str = DEEPSEEK_API_KEY):
        self.api_key = api_key
        self.api_url = DEEPSEEK_API_URL
        
    async def analyze_fundamental(self, company_data: Dict) -> Dict:
        """使用AI分析公司基本面"""
        prompt = f"""
        请分析以下公司财务数据，提供基本面投资建议：
        
        公司: {company_data.get('name')} ({company_data.get('ticker')})
        财务数据:
        {json.dumps(company_data.get('financials', {}), indent=2, ensure_ascii=False)}
        
        请提供:
        1. 财务比率分析
        2. 盈利能力评估
        3. 投资建议
        4. 风险提示
        
        请用JSON格式返回，包含以下字段:
        - ratio_analysis: 财务比率分析
        - profitability_assessment: 盈利能力评估
        - recommendation: 投资建议
        - risk_warnings: 风险提示列表
        - fundamental_score: 基本面评分 (0-100)
        """
        
        return await self._call_ai_api(prompt, "fundamental_analysis")
    
    async def _call_ai_api(self, prompt: str, analysis_type: str) -> Dict:
        """调用DeepSeek API"""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个专业的金融分析师，擅长股票分析和投资建议。请用中文回答，并确保分析专业、准确。"
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.3,
            "max_tokens": 2000
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(self.api_url, headers=headers, json=payload) as response:
                    if response.status == 200:
                        result = await response.json()
                        content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
                        
                        # 尝试解析JSON响应
                        try:
                            return json.loads(content)
                        except json.JSONDecodeError:
                            # 如果返回的不是JSON，返回原始内容
                            return {
                                "analysis_type": analysis_type,
                                "raw_response": content,
                                "timestamp": datetime.now().isoformat()
                            }
                    else:
                        error_text = await response.text()
                        logger.error(f"DeepSeek API调用失败: {response.status} - {error_text}")
                        return {
                            "analysis_type": analysis_type,
                            "error": f"API调用失败: {response.status}",
                            "timestamp": datetime.now().isoformat()
                        }
        except Exception as e:
            logger.error(f"DeepSeek API调用异常: {e}")
            return {
                "analysis_type": analysis_type,
                "error": f"API调用异常: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }

# 智能体类
class ResearchAgent:
    """个股研究智能体"""
    
    def __init__(self, data_loader: DataLoader, ai_client: DeepSeekAI):
        self.data_loader = data_loader
        self.ai_client = ai_client
        self.name = "Research Agent"
        
    async def analyze(self, ticker: str, use_ai: bool = True) -> Dict:
        """分析公司财务"""
        logger.info(f"{self.name}: 开始分析{ticker}的财务状况")
        
        company_data = self.data_loader.load_company_data(ticker)
        if not company_data:
            return {
                "agent": self.name,
                "ticker": ticker,
                "error": f"未找到{ticker}的财务数据",
                "timestamp": datetime.now().isoformat()
            }
        
        if use_ai:
            # 使用AI分析
            ai_result = await self.ai_client.analyze_fundamental(company_data)
            
            analysis = {
                "agent": self.name,
                "ticker": ticker,
                "company_name": company_data.get("name", ""),
                "timestamp": datetime.now().isoformat(),
                "analysis_method": "ai_enhanced",
                "company_data": company_data,
                "ai_analysis": ai_result,
                "fundamental_score": ai_result.get("fundamental_score", 50),
                "recommendation": ai_result.get("recommendation", "持有")
            }
        else:
            # 传统分析
            await asyncio.sleep(2)  # 模拟处理时间
            
            financials = company_data.get("financials", {})
            ratios = self._calculate_ratios(financials)
            
            analysis = {
                "agent": self.name,
                "ticker": ticker,
                "company_name": company_data.get("name", ""),
                "timestamp": datetime.now().isoformat(),
                "analysis_method": "traditional",
                "financial_ratios": ratios,
                "fundamental_score": self._calculate_score(ratios),
                "recommendation": self._generate_fundamental_recommendation(ratios)
            }
        
        logger.info(f"{self.name}: {ticker}财务分析完成")
        return analysis
    
    def _calculate_ratios(self, financials: Dict) -> Dict:
        """计算财务比率"""
        revenue = financials.get("revenue", 0)
        net_income = financials.get("net_income", 0)
        total_assets = financials.get("total_assets", 1)  # 避免除零
        equity = financials.get("equity", 1)
        
        return {
            "net_margin": (net_income / revenue * 100) if revenue > 0 else 0,
            "roe": (net_income / equity * 100) if equity > 0 else 0,
            "roa": (net_income / total_assets * 100) if total_assets > 0 else 0,
            "pe_ratio": financials.get("pe_ratio", 0),
            "pb_ratio": financials.get("pb_ratio", 0)
        }
    
    def _calculate_score(self, ratios: Dict) -> float:
        """计算基本面评分"""
        score = 0
        if ratios.get("net_margin", 0) > 10:
            score += 25
        elif ratios.get("net_margin", 0) > 5:
            score += 15
        
        if ratios.get("roe", 0) > 15:
            score += 25
        elif ratios.get("roe", 0) > 8:
            score += 15
        
        if ratios.get("pe_ratio", 0) < 20:
            score += 25
        elif ratios.get("pe_ratio", 0) < 30:
            score += 15
        
        if ratios.get("pb_ratio", 0) < 3:
            score += 25
        elif ratios.get("pb_ratio", 0) < 5:
            score += 15
        
        return score
    
    def _generate_fundamental_recommendation(self, ratios: Dict) -> str:
        """生成基本面建议"""
        score = self._calculate_score(ratios)
        
        if score >= 80:
            return "强烈买入"
        elif score >= 60:
            return "买入"
        elif score >= 40:
            return "持有"
        else:
            return "卖出"

# 总指挥智能体
class Orchestrator:
    """总指挥智能体"""
    
    def __init__(self):
        self.data_loader = DataLoader()
        self.ai_client = DeepSeekAI()
        self.research_agent = ResearchAgent(self.data_loader, self.ai_client)
        
    async def analyze_company(self, ticker: str, analysis_type: str = "full", use_ai: bool = True) -> Dict:
        """分析公司"""
        logger.info(f"开始分析公司: {ticker}，分析类型: {analysis_type}，使用AI: {use_ai}")
        
        start_time = datetime.now()
        
        try:
            # 验证分析类型
            if analysis_type not in ["full", "quick"]:
                raise ValueError(f"不支持的分析类型: {analysis_type}")
            
            # 验证股票代码是否存在数据
            company_data = self.data_loader.load_company_data(ticker)
            price_data = self.data_loader.load_price_data(ticker)
            
            if not company_data or not price_data:
                error_msg = f"未找到股票代码 '{ticker}' 的完整数据"
                logger.warning(error_msg)
                return {
                    "error": error_msg,
                    "ticker": ticker,
                    "analysis_type": analysis_type,
                    "timestamp": datetime.now().isoformat(),
                    "metadata": {
                        "processing_time": 0,
                        "analysis_type": analysis_type,
                        "timestamp": datetime.now().isoformat()
                    }
                }
            
            # 快速分析流程
            research_task = asyncio.create_task(self.research_agent.analyze(ticker, use_ai))
            research_result = await research_task
            
            # 检查智能体分析结果是否有错误
            if "error" in research_result:
                error_msg = f"研究智能体: {research_result['error']}"
                logger.error(error_msg)
                return {
                    "error": error_msg,
                    "ticker": ticker,
                    "analysis_type": analysis_type,
                    "timestamp": datetime.now().isoformat(),
                    "metadata": {
                        "processing_time": (datetime.now() - start_time).total_seconds(),
                        "analysis_type": analysis_type,
                        "timestamp": datetime.now().isoformat()
                    }
                }
            
            results = {
                "research": research_result
            }
            
            # 整合结果
            integrated_result = self._integrate_results(results, ticker, analysis_type, use_ai)
            
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            integrated_result["metadata"] = {
                "processing_time": processing_time,
                "analysis_type": analysis_type,
                "use_ai": use_ai,
                "timestamp": end_time.isoformat()
            }
            
            logger.info(f"分析完成: {ticker}，处理时间: {processing_time:.2f}秒")
            return integrated_result
            
        except ValueError as e:
            logger.error(f"分析失败: {e}")
            return {
                "error": str(e),
                "ticker": ticker,
                "analysis_type": analysis_type,
                "timestamp": datetime.now().isoformat(),
                "metadata": {
                    "processing_time": (datetime.now() - start_time).total_seconds(),
                    "analysis_type": analysis_type,
                    "timestamp": datetime.now().isoformat()
                }
            }
        except Exception as e:
            logger.error(f"分析失败: {e}")
            return {
                "error": f"系统错误: {str(e)}",
                "ticker": ticker,
                "analysis_type": analysis_type,
                "timestamp": datetime.now().isoformat(),
                "metadata": {
                    "processing_time": (datetime.now() - start_time).total_seconds(),
                    "analysis_type": analysis_type,
                    "timestamp": datetime.now().isoformat()
                }
            }
    
    def _integrate_results(self, results: Dict, ticker: str, analysis_type: str, use_ai: bool) -> Dict:
        """整合分析结果"""
        integrated = {
            "ticker": ticker,
            "analysis_type": analysis_type,
            "use_ai": use_ai,
            "timestamp": datetime.now().isoformat(),
            "summary": self._generate_summary(results),
            "recommendations": self._generate_recommendations(results),
            "detailed_analysis": results
        }
        
        # 计算综合评分
        integrated["overall_score"] = self._calculate_overall_score(results)
        integrated["risk_level"] = self._determine_risk_level(results)
        
        return integrated
    
    def _generate_summary(self, results: Dict) -> str:
        """生成分析摘要"""
        recommendations = []
        
        if "research" in results:
            recommendations.append(f"基本面: {results['research'].get('recommendation', 'N/A')}")
        
        return " | ".join(recommendations)
    
    def _generate_recommendations(self, results: Dict) -> List[str]:
        """生成详细建议"""
        recommendations = []
        
        # 基本面建议
        if "research" in results:
            research_rec = results["research"].get("recommendation")
            if research_rec:
                recommendations.append(f"投资建议: {research_rec}")
        
        return recommendations
    
    def _calculate_overall_score(self, results: Dict) -> float:
        """计算综合评分"""
        scores = []
        weights = []
        
        # 基本面评分
        if "research" in results:
            fund_score = results["research"].get("fundamental_score", 50)
            scores.append(fund_score)
            weights.append(1.0)
        
        if not scores:
            return 50.0
        
        # 加权平均
        total_weight = sum(weights)
        if total_weight == 0:
            return 50.0
        
        weighted_sum = sum(s * w for s, w in zip(scores, weights))
        return weighted_sum / total_weight
    
    def _determine_risk_level(self, results: Dict) -> str:
        """确定风险等级"""
        if "research" in results:
            fund_score = results["research"].get("fundamental_score", 50)
            if fund_score < 40:
                return "高风险"
            elif fund_score < 60:
                return "中等风险"
            else:
                return "低风险"
        return "中等风险"

# FastAPI应用
app = FastAPI(
    title="多智能体股市监测系统API",
    description="基于DeepSeek AI的多智能体股市分析系统",
    version="1.0.0"
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 在生产环境中应该限制为特定域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局变量
orchestrator = Orchestrator()

@app.get("/")
async def root():
    """根路径"""
    return {
        "message": "多智能体股市监测系统API",
        "version": "1.0.0",
        "status": "运行中",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/status")
async def get_status():
    """获取系统状态"""
    return SystemStatus(
        status="运行中",
        agents=["Orchestrator", "Research Agent"],
        api_available=True,
        timestamp=datetime.now().isoformat()
    )

@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_company(request: AnalysisRequest):
    """分析公司"""
    logger.info(f"收到分析请求: {request.ticker}, 类型: {request.analysis_type}, 使用AI: {request.use_ai}")
    
    result = await orchestrator.analyze_company(
        ticker=request.ticker,
        analysis_type=request.analysis_type,
        use_ai=request.use_ai
    )
    
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    
    return result

@app.get("/analyze/{ticker}")
async def analyze_company_get(
    ticker: str,
    analysis_type: str = Query("full", description="分析类型: full或quick"),
    use_ai: bool = Query(True, description="是否使用AI分析")
):
    """GET方式分析公司"""
    logger.info(f"收到GET分析请求: {ticker}, 类型: {analysis_type}, 使用AI: {use_ai}")
    
    result = await orchestrator.analyze_company(
        ticker=ticker,
        analysis_type=analysis_type,
        use_ai=use_ai
    )
    
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    
    return result

@app.get("/companies")
async def get_available_companies():
    """获取可分析的公司列表"""
    data_loader = DataLoader()
    financials_file = Path("data/company_financials.json")
    
    if not financials_file.exists():
        return {"companies": []}
    
    try:
        with open(financials_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            companies = data.get("companies", [])
            
            # 只返回基本信息
            simplified_companies = []
            for company in companies:
                simplified_companies.append({
                    "ticker": company.get("ticker"),
                    "name": company.get("name"),
                    "sector": company.get("sector"),
                    "industry": company.get("industry")
                })
            
            return {
                "count": len(simplified_companies),
                "companies": simplified_companies
            }
    except Exception as e:
        logger.error(f"获取公司列表失败: {e}")
        return {"companies": [], "error": str(e)}

@app.get("/market/overview")
async def get_market_overview():
    """获取市场概况"""
    data_loader = DataLoader()
    market_data = data_loader.load_market_data()
    return market_data

def main():
    """主函数"""
    print("=" * 60)
    print("多智能体股市监测系统API服务器")
    print("基于DeepSeek AI的多智能体股市分析系统")
    print("=" * 60)
    print(f"API地址: http://localhost:8000")
    print(f"文档地址: http://localhost:8000/docs")
    print(f"DeepSeek API密钥: {DEEPSEEK_API_KEY[:10]}...")
    print("=" * 60)
    
    # 创建日志目录
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)
    
    # 启动服务器
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info",
        reload=True
    )

if __name__ == "__main__":
    main()
