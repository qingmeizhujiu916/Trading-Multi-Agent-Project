#!/usr/bin/env python3
"""
测试API服务器是否正常工作
"""

import asyncio
import aiohttp
import json
import sys

async def test_api():
    """测试API服务器"""
    print("测试多智能体股市监测系统API...")
    print("=" * 60)
    
    base_url = "http://localhost:8000"
    
    try:
        async with aiohttp.ClientSession() as session:
            # 测试根路径
            print("1. 测试根路径...")
            async with session.get(f"{base_url}/") as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"   ✓ 成功: {data.get('message')}")
                else:
                    print(f"   ✗ 失败: HTTP {response.status}")
                    return False
            
            # 测试状态接口
            print("2. 测试系统状态...")
            async with session.get(f"{base_url}/status") as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"   ✓ 成功: 状态={data.get('status')}, 智能体数量={len(data.get('agents', []))}")
                else:
                    print(f"   ✗ 失败: HTTP {response.status}")
                    return False
            
            # 测试获取公司列表
            print("3. 测试获取公司列表...")
            async with session.get(f"{base_url}/companies") as response:
                if response.status == 200:
                    data = await response.json()
                    companies = data.get('companies', [])
                    print(f"   ✓ 成功: 找到{len(companies)}家公司")
                    for company in companies[:3]:  # 显示前3家公司
                        print(f"     - {company.get('ticker')}: {company.get('name')}")
                else:
                    print(f"   ✗ 失败: HTTP {response.status}")
                    return False
            
            # 测试获取市场概况
            print("4. 测试获取市场概况...")
            async with session.get(f"{base_url}/market/overview") as response:
                if response.status == 200:
                    data = await response.json()
                    market_condition = data.get('market_overview', {}).get('market_condition', '未知')
                    print(f"   ✓ 成功: 市场状况={market_condition}")
                else:
                    print(f"   ✗ 失败: HTTP {response.status}")
                    return False
            
            # 测试快速分析
            print("5. 测试快速分析AAPL...")
            async with session.get(f"{base_url}/analyze/AAPL?analysis_type=quick&use_ai=true") as response:
                if response.status == 200:
                    data = await response.json()
                    ticker = data.get('ticker', '未知')
                    score = data.get('overall_score', 0)
                    risk = data.get('risk_level', '未知')
                    print(f"   ✓ 成功: {ticker} 综合评分={score:.1f}, 风险等级={risk}")
                    
                    # 显示详细结果
                    print(f"     摘要: {data.get('summary', '')}")
                    print(f"     建议: {', '.join(data.get('recommendations', [])[:2])}")
                else:
                    error_text = await response.text()
                    print(f"   ✗ 失败: HTTP {response.status} - {error_text}")
                    return False
            
            # 测试完整分析
            print("6. 测试完整分析TSLA...")
            async with session.get(f"{base_url}/analyze/TSLA?analysis_type=full&use_ai=true") as response:
                if response.status == 200:
                    data = await response.json()
                    ticker = data.get('ticker', '未知')
                    score = data.get('overall_score', 0)
                    risk = data.get('risk_level', '未知')
                    print(f"   ✓ 成功: {ticker} 综合评分={score:.1f}, 风险等级={risk}")
                    
                    # 检查智能体分析结果
                    detailed = data.get('detailed_analysis', {})
                    agents = list(detailed.keys())
                    print(f"     参与分析的智能体: {', '.join(agents)}")
                else:
                    error_text = await response.text()
                    print(f"   ✗ 失败: HTTP {response.status} - {error_text}")
                    return False
            
            print("\n" + "=" * 60)
            print("所有测试通过！系统运行正常。")
            print("=" * 60)
            return True
            
    except aiohttp.ClientConnectorError:
        print("   ✗ 失败: 无法连接到API服务器")
        print("     请确保API服务器正在运行: python api_server.py")
        return False
    except Exception as e:
        print(f"   ✗ 失败: {e}")
        return False

def main():
    """主函数"""
    print("多智能体股市监测系统 - API测试")
    print("=" * 60)
    
    try:
        success = asyncio.run(test_api())
        if success:
            print("\n测试完成！系统已准备就绪。")
            print("\n使用说明:")
            print("1. 启动API服务器: python api_server.py")
            print("2. 访问前端页面: frontend/index.html")
            print("3. 使用分析功能: 选择公司并点击'开始分析'或'快速分析'")
            print("4. 查看API文档: http://localhost:8000/docs")
        else:
            print("\n测试失败！请检查系统配置。")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n测试被用户中断")
        sys.exit(0)

if __name__ == "__main__":
    main()