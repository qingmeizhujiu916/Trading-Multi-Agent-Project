#!/usr/bin/env python3
"""
多智能体股市监测系统 - 主程序
基于OpenClaw框架的五智能体协作系统
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/system.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DataLoader:
    """数据加载器 - 从本地JSON文件加载数据"""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
    def load_market_data(self) -> Dict:
        """加载市场宏观数据"""
        market_file = self.data_dir / "market_overview.json"
        if not market_file.exists():
            logger.warning(f"市场数据文件不存在: {market_file}")
            return self._create_sample_market_data()
        
        try:
            with open(market_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载市场数据失败: {e}")
            return self._create_sample_market_data()
    
    def load_company_data(self, ticker: str) -> Optional[Dict]:
        """加载公司财务数据"""
        financials_file = self.data_dir / "company_financials.json"
        if not financials_file.exists():
            logger.warning(f"财务数据文件不存在: {financials_file}")
            return None
        
        try:
            with open(financials_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for company in data.get("companies", []):
                    if company.get("ticker") == ticker:
                        return company
        except Exception as e:
            logger.error(f"加载财务数据失败: {e}")
        
        return None
    
    def load_price_data(self, ticker: str) -> Optional[List[Dict]]:
        """加载价格历史数据"""
        price_file = self.data_dir / "price_history.json"
        if not price_file.exists():
            logger.warning(f"价格数据文件不存在: {price_file}")
            return None
        
        try:
            with open(price_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for company in data.get("companies", []):
                    if company.get("ticker") == ticker:
                        return company.get("price_history", [])
        except Exception as e:
            logger.error(f"加载价格数据失败: {e}")
        
        return None
    
    def _create_sample_market_data(self) -> Dict:
        """创建示例市场数据"""
        return {
            "timestamp": datetime.now().isoformat(),
            "market_overview": {
                "market_condition": "neutral",
                "risk_level": "medium",
                "major_indices": {
                    "sp500": {"value": 5200.45, "change": 15.32},
                    "nasdaq": {"value": 16250.78, "change": 45.21},
                    "dow_jones": {"value": 39500.12, "change": 120.45}
                }
            }
        }

class MacroAgent:
    """宏观分析智能体"""
    
    def __init__(self, data_loader: DataLoader):
        self.data_loader = data_loader
        self.name = "Macro Agent"
        
    async def analyze(self, ticker: str) -> Dict:
        """分析宏观环境"""
        logger.info(f"{self.name}: 开始分析{ticker}的宏观环境")
        
        market_data = self.data_loader.load_market_data()
        
        # 模拟分析过程
        await asyncio.sleep(1)  # 模拟处理时间
        
        analysis = {
            "agent": self.name,
            "ticker": ticker,
            "timestamp": datetime.now().isoformat(),
            "market_condition": market_data.get("market_overview", {}).get("market_condition", "unknown"),
            "risk_level": market_data.get("market_overview", {}).get("risk_level", "unknown"),
            "recommendation": self._generate_recommendation(market_data),
            "key_indicators": self._extract_indicators(market_data)
        }
        
        logger.info(f"{self.name}: {ticker}宏观分析完成")
        return analysis
    
    def _generate_recommendation(self, market_data: Dict) -> str:
        """生成宏观建议"""
        condition = market_data.get("market_overview", {}).get("market_condition", "neutral")
        risk = market_data.get("market_overview", {}).get("risk_level", "medium")
        
        if condition == "bullish" and risk == "low":
            return "积极投资"
        elif condition == "bearish" and risk == "high":
            return "谨慎观望"
        else:
            return "中性持有"
    
    def _extract_indicators(self, market_data: Dict) -> Dict:
        """提取关键指标"""
        indices = market_data.get("market_overview", {}).get("major_indices", {})
        return {
            "sp500_change": indices.get("sp500", {}).get("change", 0),
            "nasdaq_change": indices.get("nasdaq", {}).get("change", 0),
            "dow_change": indices.get("dow_jones", {}).get("change", 0)
        }

class ResearchAgent:
    """个股研究智能体"""
    
    def __init__(self, data_loader: DataLoader):
        self.data_loader = data_loader
        self.name = "Research Agent"
        
    async def analyze(self, ticker: str) -> Dict:
        """分析公司财务"""
        logger.info(f"{self.name}: 开始分析{ticker}的财务状况")
        
        company_data = self.data_loader.load_company_data(ticker)
        if not company_data:
            return {
                "agent": self.name,
                "ticker": ticker,
                "error": f"未找到{ticker}的财务数据",
                "timestamp": datetime.now().isoformat()
            }
        
        # 模拟分析过程
        await asyncio.sleep(2)  # 模拟处理时间
        
        financials = company_data.get("financials", {})
        ratios = self._calculate_ratios(financials)
        
        analysis = {
            "agent": self.name,
            "ticker": ticker,
            "company_name": company_data.get("name", ""),
            "timestamp": datetime.now().isoformat(),
            "financial_ratios": ratios,
            "fundamental_score": self._calculate_score(ratios),
            "recommendation": self._generate_fundamental_recommendation(ratios)
        }
        
        logger.info(f"{self.name}: {ticker}财务分析完成")
        return analysis
    
    def _calculate_ratios(self, financials: Dict) -> Dict:
        """计算财务比率"""
        revenue = financials.get("revenue", 0)
        net_income = financials.get("net_income", 0)
        total_assets = financials.get("total_assets", 1)  # 避免除零
        equity = financials.get("equity", 1)
        
        return {
            "net_margin": (net_income / revenue * 100) if revenue > 0 else 0,
            "roe": (net_income / equity * 100) if equity > 0 else 0,
            "roa": (net_income / total_assets * 100) if total_assets > 0 else 0,
            "pe_ratio": financials.get("pe_ratio", 0),
            "pb_ratio": financials.get("pb_ratio", 0)
        }
    
    def _calculate_score(self, ratios: Dict) -> float:
        """计算基本面评分"""
        score = 0
        if ratios.get("net_margin", 0) > 10:
            score += 25
        elif ratios.get("net_margin", 0) > 5:
            score += 15
        
        if ratios.get("roe", 0) > 15:
            score += 25
        elif ratios.get("roe", 0) > 8:
            score += 15
        
        if ratios.get("pe_ratio", 0) < 20:
            score += 25
        elif ratios.get("pe_ratio", 0) < 30:
            score += 15
        
        if ratios.get("pb_ratio", 0) < 3:
            score += 25
        elif ratios.get("pb_ratio", 0) < 5:
            score += 15
        
        return score
    
    def _generate_fundamental_recommendation(self, ratios: Dict) -> str:
        """生成基本面建议"""
        score = self._calculate_score(ratios)
        
        if score >= 80:
            return "强烈买入"
        elif score >= 60:
            return "买入"
        elif score >= 40:
            return "持有"
        else:
            return "卖出"

class TradingAgent:
    """交易策略智能体"""
    
    def __init__(self, data_loader: DataLoader):
        self.data_loader = data_loader
        self.name = "Trading Agent"
        
    async def analyze(self, ticker: str) -> Dict:
        """分析交易策略"""
        logger.info(f"{self.name}: 开始分析{ticker}的交易策略")
        
        price_data = self.data_loader.load_price_data(ticker)
        if not price_data:
            return {
                "agent": self.name,
                "ticker": ticker,
                "error": f"未找到{ticker}的价格数据",
                "timestamp": datetime.now().isoformat()
            }
        
        # 模拟分析过程
        await asyncio.sleep(1.5)  # 模拟处理时间
        
        signals = self._generate_signals(price_data)
        
        analysis = {
            "agent": self.name,
            "ticker": ticker,
            "timestamp": datetime.now().isoformat(),
            "current_price": price_data[-1]["close"] if price_data else 0,
            "technical_signals": signals,
            "trading_recommendation": self._generate_trading_recommendation(signals),
            "confidence": self._calculate_confidence(signals)
        }
        
        logger.info(f"{self.name}: {ticker}交易分析完成")
        return analysis
    
    def _generate_signals(self, price_data: List[Dict]) -> Dict:
        """生成技术信号"""
        if len(price_data) < 10:
            return {"error": "数据不足"}
        
        closes = [p["close"] for p in price_data]
        
        # 计算简单移动平均线
        ma5 = sum(closes[-5:]) / 5 if len(closes) >= 5 else closes[-1]
        ma10 = sum(closes[-10:]) / 10 if len(closes) >= 10 else closes[-1]
        
        current_price = closes[-1]
        
        return {
            "ma5": ma5,
            "ma10": ma10,
            "price_vs_ma5": "above" if current_price > ma5 else "below",
            "price_vs_ma10": "above" if current_price > ma10 else "below",
            "trend": "up" if ma5 > ma10 else "down"
        }
    
    def _generate_trading_recommendation(self, signals: Dict) -> str:
        """生成交易建议"""
        if "error" in signals:
            return "数据不足"
        
        if signals.get("price_vs_ma5") == "above" and signals.get("price_vs_ma10") == "above":
            return "买入"
        elif signals.get("price_vs_ma5") == "below" and signals.get("price_vs_ma10") == "below":
            return "卖出"
        else:
            return "持有"
    
    def _calculate_confidence(self, signals: Dict) -> float:
        """计算信心度"""
        if "error" in signals:
            return 0.0
        
        confidence = 0.5  # 基础信心度
        
        if signals.get("trend") == "up":
            confidence += 0.2
        if signals.get("price_vs_ma5") == signals.get("price_vs_ma10"):
            confidence += 0.3
        
        return min(confidence, 1.0)

class ExecutorAgent:
    """执行监控智能体"""
    
    def __init__(self):
        self.name = "Executor Agent"
        
    async def analyze(self, macro_result: Dict, research_result: Dict, trading_result: Dict) -> Dict:
        """监控执行风险"""
        logger.info(f"{self.name}: 开始监控执行风险")
        
        # 模拟分析过程
        await asyncio.sleep(0.5)  # 模拟处理时间
        
        risk_score = self._calculate_risk_score(macro_result, research_result, trading_result)
        
        analysis = {
            "agent": self.name,
            "timestamp": datetime.now().isoformat(),
            "risk_assessment": {
                "overall_risk": risk_score,
                "risk_level": self._get_risk_level(risk_score),
                "recommendations": self._generate_risk_recommendations(risk_score)
            },
            "monitoring_points": [
                "市场波动性",
                "流动性风险",
                "执行滑点",
                "交易成本"
            ]
        }
        
        logger.info(f"{self.name}: 执行风险监控完成")
        return analysis
    
    def _calculate_risk_score(self, macro: Dict, research: Dict, trading: Dict) -> float:
        """计算风险评分"""
        score = 0.5  # 基础风险
        
        # 宏观风险
        macro_risk = macro.get("risk_level", "medium")
        if macro_risk == "high":
            score += 0.3
        elif macro_risk == "low":
            score -= 0.2
        
        # 基本面风险
        if "fundamental_score" in research:
            fund_score = research["fundamental_score"]
            if fund_score < 40:
                score += 0.2
            elif fund_score > 80:
                score -= 0.2
        
        # 技术面风险
        if "confidence" in trading:
            tech_confidence = trading["confidence"]
            score += (1 - tech_confidence) * 0.3
        
        return max(0.0, min(score, 1.0))
    
    def _get_risk_level(self, risk_score: float) -> str:
        """获取风险等级"""
        if risk_score < 0.3:
            return "低风险"
        elif risk_score < 0.6:
            return "中等风险"
        else:
            return "高风险"
    
    def _generate_risk_recommendations(self, risk_score: float) -> List[str]:
        """生成风险建议"""
        recommendations = []
        
        if risk_score > 0.7:
            recommendations.extend([
                "建议降低仓位",
                "设置严格止损",
                "分批建仓"
            ])
        elif risk_score > 0.4:
            recommendations.extend([
                "控制单笔交易规模",
                "设置合理止损",
                "关注市场动态"
            ])
        else:
            recommendations.extend([
                "可适当增加仓位",
                "设置移动止损",
                "长期持有"
            ])
        
        return recommendations

class Orchestrator:
    """总指挥智能体"""
    
    def __init__(self):
        self.data_loader = DataLoader()
        self.macro_agent = MacroAgent(self.data_loader)
        self.research_agent = ResearchAgent(self.data_loader)
        self.trading_agent = TradingAgent(self.data_loader)
        self.executor_agent = ExecutorAgent()
        
    async def analyze_company(self, ticker: str, analysis_type: str = "full") -> Dict:
        """分析公司"""
        logger.info(f"开始分析公司: {ticker}，分析类型: {analysis_type}")
        
        start_time = datetime.now()
        
        try:
            # 验证分析类型
            if analysis_type not in ["full", "quick"]:
                raise ValueError(f"不支持的分析类型: {analysis_type}")
            
            # 验证股票代码是否存在数据
            company_data = self.data_loader.load_company_data(ticker)
            price_data = self.data_loader.load_price_data(ticker)
            
            if not company_data or not price_data:
                error_msg = f"未找到股票代码 '{ticker}' 的完整数据"
                logger.warning(error_msg)
                return {
                    "error": error_msg,
                    "ticker": ticker,
                    "analysis_type": analysis_type,
                    "timestamp": datetime.now().isoformat(),
                    "metadata": {
                        "processing_time": 0,
                        "analysis_type": analysis_type,
                        "timestamp": datetime.now().isoformat()
                    }
                }
            
            if analysis_type == "full":
                # 完整分析流程
                macro_task = asyncio.create_task(self.macro_agent.analyze(ticker))
                research_task = asyncio.create_task(self.research_agent.analyze(ticker))
                trading_task = asyncio.create_task(self.trading_agent.analyze(ticker))
                
                macro_result, research_result, trading_result = await asyncio.gather(
                    macro_task, research_task, trading_task
                )
                
                # 检查智能体分析结果是否有错误
                agent_errors = []
                if "error" in research_result:
                    agent_errors.append(f"研究智能体: {research_result['error']}")
                if "error" in trading_result:
                    agent_errors.append(f"交易智能体: {trading_result['error']}")
                
                if agent_errors:
                    error_msg = f"智能体分析失败: {'; '.join(agent_errors)}"
                    logger.error(error_msg)
                    return {
                        "error": error_msg,
                        "ticker": ticker,
                        "analysis_type": analysis_type,
                        "timestamp": datetime.now().isoformat(),
                        "metadata": {
                            "processing_time": (datetime.now() - start_time).total_seconds(),
                            "analysis_type": analysis_type,
                            "timestamp": datetime.now().isoformat()
                        }
                    }
                
                executor_result = await self.executor_agent.analyze(
                    macro_result, research_result, trading_result
                )
                
                results = {
                    "macro": macro_result,
                    "research": research_result,
                    "trading": trading_result,
                    "executor": executor_result
                }
                
            elif analysis_type == "quick":
                # 快速分析流程
                research_task = asyncio.create_task(self.research_agent.analyze(ticker))
                trading_task = asyncio.create_task(self.trading_agent.analyze(ticker))
                
                research_result, trading_result = await asyncio.gather(
                    research_task, trading_task
                )
                
                # 检查智能体分析结果是否有错误
                agent_errors = []
                if "error" in research_result:
                    agent_errors.append(f"研究智能体: {research_result['error']}")
                if "error" in trading_result:
                    agent_errors.append(f"交易智能体: {trading_result['error']}")
                
                if agent_errors:
                    error_msg = f"智能体分析失败: {'; '.join(agent_errors)}"
                    logger.error(error_msg)
                    return {
                        "error": error_msg,
                        "ticker": ticker,
                        "analysis_type": analysis_type,
                        "timestamp": datetime.now().isoformat(),
                        "metadata": {
                            "processing_time": (datetime.now() - start_time).total_seconds(),
                            "analysis_type": analysis_type,
                            "timestamp": datetime.now().isoformat()
                        }
                    }
                
                results = {
                    "research": research_result,
                    "trading": trading_result
                }
            
            # 整合结果
            integrated_result = self._integrate_results(results, ticker, analysis_type)
            
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            integrated_result["metadata"] = {
                "processing_time": processing_time,
                "analysis_type": analysis_type,
                "timestamp": end_time.isoformat()
            }
            
            logger.info(f"分析完成: {ticker}，处理时间: {processing_time:.2f}秒")
            return integrated_result
            
        except ValueError as e:
            logger.error(f"分析失败: {e}")
            return {
                "error": str(e),
                "ticker": ticker,
                "analysis_type": analysis_type,
                "timestamp": datetime.now().isoformat(),
                "metadata": {
                    "processing_time": (datetime.now() - start_time).total_seconds(),
                    "analysis_type": analysis_type,
                    "timestamp": datetime.now().isoformat()
                }
            }
        except Exception as e:
            logger.error(f"分析失败: {e}")
            return {
                "error": f"系统错误: {str(e)}",
                "ticker": ticker,
                "analysis_type": analysis_type,
                "timestamp": datetime.now().isoformat(),
                "metadata": {
                    "processing_time": (datetime.now() - start_time).total_seconds(),
                    "analysis_type": analysis_type,
                    "timestamp": datetime.now().isoformat()
                }
            }
    
    def _integrate_results(self, results: Dict, ticker: str, analysis_type: str) -> Dict:
        """整合分析结果"""
        integrated = {
            "ticker": ticker,
            "analysis_type": analysis_type,
            "timestamp": datetime.now().isoformat(),
            "summary": self._generate_summary(results),
            "recommendations": self._generate_recommendations(results),
            "detailed_analysis": results
        }
        
        # 计算综合评分
        integrated["overall_score"] = self._calculate_overall_score(results)
        integrated["risk_level"] = self._determine_risk_level(results)
        
        return integrated
    
    def _generate_summary(self, results: Dict) -> str:
        """生成分析摘要"""
        recommendations = []
        
        if "macro" in results:
            recommendations.append(f"宏观分析: {results['macro'].get('recommendation', 'N/A')}")
        
        if "research" in results:
            recommendations.append(f"基本面: {results['research'].get('recommendation', 'N/A')}")
        
        if "trading" in results:
            recommendations.append(f"技术面: {results['trading'].get('trading_recommendation', 'N/A')}")
        
        if "executor" in results:
            risk_level = results['executor'].get('risk_assessment', {}).get('risk_level', '未知')
            recommendations.append(f"风险等级: {risk_level}")
        
        return " | ".join(recommendations)
    
    def _generate_recommendations(self, results: Dict) -> List[str]:
        """生成详细建议"""
        recommendations = []
        
        # 宏观建议
        if "macro" in results:
            macro_rec = results["macro"].get("recommendation")
            if macro_rec:
                recommendations.append(f"宏观策略: {macro_rec}")
        
        # 基本面建议
        if "research" in results:
            research_rec = results["research"].get("recommendation")
            if research_rec:
                recommendations.append(f"投资建议: {research_rec}")
        
        # 技术面建议
        if "trading" in results:
            trading_rec = results["trading"].get("trading_recommendation")
            if trading_rec:
                recommendations.append(f"交易策略: {trading_rec}")
        
        # 风险控制建议
        if "executor" in results:
            risk_recs = results["executor"].get("risk_assessment", {}).get("recommendations", [])
            recommendations.extend([f"风险控制: {rec}" for rec in risk_recs[:2]])
        
        return recommendations
    
    def _calculate_overall_score(self, results: Dict) -> float:
        """计算综合评分"""
        scores = []
        weights = []
        
        # 宏观评分
        if "macro" in results:
            macro_risk = results["macro"].get("risk_level", "medium")
            if macro_risk == "low":
                scores.append(80)
            elif macro_risk == "medium":
                scores.append(60)
            else:
                scores.append(40)
            weights.append(0.2)
        
        # 基本面评分
        if "research" in results:
            fund_score = results["research"].get("fundamental_score", 50)
            scores.append(fund_score)
            weights.append(0.4)
        
        # 技术面评分
        if "trading" in results:
            tech_confidence = results["trading"].get("confidence", 0.5)
            scores.append(tech_confidence * 100)
            weights.append(0.3)
        
        # 风险评分
        if "executor" in results:
            risk_score = results["executor"].get("risk_assessment", {}).get("overall_risk", 0.5)
            scores.append((1 - risk_score) * 100)  # 风险越低分数越高
            weights.append(0.1)
        
        if not scores:
            return 50.0
        
        # 加权平均
        total_weight = sum(weights)
        if total_weight == 0:
            return 50.0
        
        weighted_sum = sum(s * w for s, w in zip(scores, weights))
        return weighted_sum / total_weight
    
    def _determine_risk_level(self, results: Dict) -> str:
        """确定风险等级"""
        if "executor" in results:
            return results["executor"].get("risk_assessment", {}).get("risk_level", "中等风险")
        
        # 如果没有执行监控结果，根据其他结果判断
        risk_factors = []
        
        if "macro" in results:
            macro_risk = results["macro"].get("risk_level", "medium")
            if macro_risk == "high":
                risk_factors.append(2)
            elif macro_risk == "medium":
                risk_factors.append(1)
            else:
                risk_factors.append(0)
        
        if "research" in results:
            fund_score = results["research"].get("fundamental_score", 50)
            if fund_score < 40:
                risk_factors.append(2)
            elif fund_score < 60:
                risk_factors.append(1)
            else:
                risk_factors.append(0)
        
        if not risk_factors:
            return "中等风险"
        
        avg_risk = sum(risk_factors) / len(risk_factors)
        
        if avg_risk > 1.5:
            return "高风险"
        elif avg_risk > 0.5:
            return "中等风险"
        else:
            return "低风险"

async def main():
    """主函数"""
    print("=" * 60)
    print("多智能体股市监测系统")
    print("基于OpenClaw框架的五智能体协作系统")
    print("=" * 60)
    
    # 创建日志目录
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)
    
    orchestrator = Orchestrator()
    
    while True:
        print("\n请选择操作:")
        print("1. 分析单个公司")
        print("2. 批量分析公司")
        print("3. 查看系统状态")
        print("4. 退出系统")
        
        choice = input("\n请输入选项 (1-4): ").strip()
        
        if choice == "1":
            ticker = input("请输入公司代码 (如 AAPL, TSLA, BABA): ").strip().upper()
            analysis_type = input("分析类型 (full/quick, 默认full): ").strip().lower()
            if not analysis_type:
                analysis_type = "full"
            
            print(f"\n开始分析 {ticker}...")
            result = await orchestrator.analyze_company(ticker, analysis_type)
            
            print(f"\n分析完成!")
            print(f"公司: {result.get('ticker')}")
            print(f"分析类型: {result.get('analysis_type')}")
            print(f"处理时间: {result.get('metadata', {}).get('processing_time', 0):.2f}秒")
            print(f"综合评分: {result.get('overall_score', 0):.1f}/100")
            print(f"风险等级: {result.get('risk_level', '未知')}")
            print(f"摘要: {result.get('summary', '')}")
            
            print("\n详细建议:")
            for i, rec in enumerate(result.get('recommendations', []), 1):
                print(f"  {i}. {rec}")
        
        elif choice == "2":
            tickers_input = input("请输入公司代码列表 (用逗号分隔): ").strip()
            tickers = [t.strip().upper() for t in tickers_input.split(",") if t.strip()]
            
            if not tickers:
                print("错误: 请输入有效的公司代码")
                continue
            
            print(f"\n开始批量分析 {len(tickers)} 个公司...")
            
            for ticker in tickers:
                print(f"\n分析 {ticker}...")
                try:
                    result = await orchestrator.analyze_company(ticker, "quick")
                    print(f"  ✓ 完成: {result.get('summary', '')}")
                except Exception as e:
                    print(f"  ✗ 失败: {e}")
        
        elif choice == "3":
            print("\n系统状态:")
            print(f"数据目录: {Path('data').absolute()}")
            print(f"日志目录: {Path('logs').absolute()}")
            print(f"智能体数量: 5 (Orchestrator, Macro, Research, Trading, Executor)")
            print("所有智能体状态: 正常")
        
        elif choice == "4":
            print("\n感谢使用多智能体股市监测系统!")
            break
        
        else:
            print("错误: 请输入有效的选项 (1-4)")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n系统被用户中断")
    except Exception as e:
        print(f"\n系统错误: {e}")
        import traceback
        traceback.print_exc()
