# 多智能体股市监测系统 - 前端组件示例

## 🎯 核心组件实现

### 1. 主仪表板布局组件 (DashboardLayout.tsx)

```tsx
import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, Shield, Cpu, Bell, Settings } from 'lucide-react';
import Header from './Header';
import Sidebar from './Sidebar';
import MarketOverviewCard from '../charts/MarketOverviewCard';
import AgentStatusCard from '../agents/AgentStatusCard';
import AnalysisQueue from '../agents/AnalysisQueue';
import RecentReports from './RecentReports';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = React.useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-950 text-gray-100">
      {/* 顶部导航栏 */}
      <Header 
        sidebarOpen={sidebarOpen}
        onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
      />
      
      <div className="flex">
        {/* 侧边栏 */}
        <Sidebar open={sidebarOpen} />
        
        {/* 主内容区域 */}
        <main className="flex-1 p-6 overflow-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-7xl mx-auto"
          >
            {/* 欢迎横幅 */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
                多智能体股市监测系统
              </h1>
              <p className="text-gray-400 mt-2">
                实时市场分析 · 智能投资决策 · 风险监控
              </p>
            </div>

            {/* 关键指标速览 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 hover:border-blue-500/30 transition-all duration-300">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">市场状态</p>
                    <p className="text-2xl font-bold mt-2">Bullish</p>
                  </div>
                  <div className="p-3 bg-blue-500/10 rounded-lg">
                    <TrendingUp className="w-6 h-6 text-blue-400" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-green-500 to-emerald-400 w-3/4"></div>
                  </div>
                  <p className="text-xs text-gray-400 mt-2">75% 积极信号</p>
                </div>
              </div>

              <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 hover:border-amber-500/30 transition-all duration-300">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">活跃智能体</p>
                    <p className="text-2xl font-bold mt-2">5/5</p>
                  </div>
                  <div className="p-3 bg-amber-500/10 rounded-lg">
                    <Cpu className="w-6 h-6 text-amber-400" />
                  </div>
                </div>
                <p className="text-sm text-gray-400 mt-2">全部在线运行</p>
              </div>

              <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 hover:border-emerald-500/30 transition-all duration-300">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">今日分析</p>
                    <p className="text-2xl font-bold mt-2">24</p>
                  </div>
                  <div className="p-3 bg-emerald-500/10 rounded-lg">
                    <BarChart3 className="w-6 h-6 text-emerald-400" />
                  </div>
                </div>
                <p className="text-sm text-gray-400 mt-2">+8% 较昨日</p>
              </div>

              <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 hover:border-red-500/30 transition-all duration-300">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">风险等级</p>
                    <p className="text-2xl font-bold mt-2">中等</p>
                  </div>
                  <div className="p-3 bg-red-500/10 rounded-lg">
                    <Shield className="w-6 h-6 text-red-400" />
                  </div>
                </div>
                <p className="text-sm text-gray-400 mt-2">监控中</p>
              </div>
            </div>

            {/* 主要内容区域 */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* 左侧：市场概览和智能体状态 */}
              <div className="lg:col-span-2 space-y-6">
                <MarketOverviewCard />
                <AgentStatusCard />
              </div>

              {/* 右侧：分析队列和最近报告 */}
              <div className="space-y-6">
                <AnalysisQueue />
                <RecentReports />
              </div>
            </div>

            {/* 子页面内容 */}
            <div className="mt-8">
              {children}
            </div>
          </motion.div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
```

### 2. 智能体状态卡片组件 (AgentStatusCard.tsx)

```tsx
import React from 'react';
import { motion } from 'framer-motion';
import { Cpu, Clock, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

interface AgentStatus {
  id: string;
  name: string;
  status: 'idle' | 'processing' | 'success' | 'error';
  lastRun: string;
  processingTime?: number;
  description: string;
}

const AgentStatusCard: React.FC = () => {
  const agents: AgentStatus[] = [
    {
      id: 'orchestrator',
      name: '总指挥智能体',
      status: 'success',
      lastRun: '2分钟前',
      processingTime: 45,
      description: '协调所有智能体工作流'
    },
    {
      id: 'macro',
      name: '宏观分析智能体',
      status: 'processing',
      lastRun: '进行中',
      processingTime: 120,
      description: '分析市场整体趋势'
    },
    {
      id: 'research',
      name: '个股研究智能体',
      status: 'idle',
      lastRun: '5分钟前',
      processingTime: 180,
      description: '深度财务分析'
    },
    {
      id: 'trading',
      name: '交易策略智能体',
      status: 'success',
      lastRun: '3分钟前',
      processingTime: 90,
      description: '制定交易计划'
    },
    {
      id: 'executor',
      name: '执行监控智能体',
      status: 'idle',
      lastRun: '10分钟前',
      processingTime: 60,
      description: '监控执行风险'
    }
  ];

  const getStatusColor = (status: AgentStatus['status']) => {
    switch (status) {
      case 'success': return 'text-emerald-400';
      case 'processing': return 'text-amber-400';
      case 'error': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: AgentStatus['status']) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-5 h-5" />;
      case 'processing': return <Loader2 className="w-5 h-5 animate-spin" />;
      case 'error': return <AlertCircle className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-white">智能体状态监控</h3>
          <p className="text-sm text-gray-400">实时监控各智能体运行状态</p>
        </div>
        <div className="p-2 bg-blue-500/10 rounded-lg">
          <Cpu className="w-6 h-6 text-blue-400" />
        </div>
      </div>

      <div className="space-y-4">
        {agents.map((agent, index) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center justify-between p-4 bg-gray-900/50 rounded-lg hover:bg-gray-900/70 transition-colors"
          >
            <div className="flex items-center space-x-4">
              <div className={`p-2 rounded-lg ${getStatusColor(agent.status).replace('text-', 'bg-')}/10`}>
                {getStatusIcon(agent.status)}
              </div>
              <div>
                <h4 className="font-medium text-white">{agent.name}</h4>
                <p className="text-sm text-gray-400">{agent.description}</p>
              </div>
            </div>

            <div className="text-right">
              <div className={`font-medium ${getStatusColor(agent.status)}`}>
                {agent.status === 'processing' ? '处理中' : 
                 agent.status === 'success' ? '就绪' : 
                 agent.status === 'error' ? '错误' : '空闲'}
              </div>
              <div className="text-xs text-gray-400 mt-1">
                上次运行: {agent.lastRun}
                {agent.processingTime && ` · ${agent.processingTime}s`}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* 工作流可视化 */}
      <div className="mt-6 pt-6 border-t border-gray-700/50">
        <h4 className="text-sm font-medium text-gray-300 mb-4">智能体协作工作流</h4>
        <div className="flex items-center justify-center space-x-2">
          {agents.map((agent, index) => (
            <React.Fragment key={agent.id}>
              <div className="flex flex-col items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  agent.status === 'success' ? 'bg-emerald-500/20 border border-emerald-500/30' :
                  agent.status === 'processing' ? 'bg-amber-500/20 border border-amber-500/30 animate-pulse' :
                  'bg-gray-800 border border-gray-700'
                }`}>
                  <span className="text-xs font-bold">{agent.name.charAt(0)}</span>
                </div>
                <span className="text-xs text-gray-400 mt-2">{agent.name.split(' ')[0]}</span>
              </div>
              {index < agents.length - 1 && (
                <div className="w-8 h-0.5 bg-gray-700"></div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AgentStatusCard;
```

### 3. 市场概览图表组件 (MarketChart.tsx)

```tsx
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface MarketDataPoint {
  time: string;
  value: number;
  change: number;
}

interface MarketChartProps {
  data: MarketDataPoint[];
  title: string;
  color: string;
  showChange?: boolean;
}

const MarketChart: React.FC<MarketChartProps> = ({ 
  data, 
  title, 
  color,
  showChange = true 
}) => {
  const [timeRange, setTimeRange] = useState<'1d' | '1w' | '1m' | '3m'>('1w');

  const calculateChange = () => {
    if (data.length < 2) return 0;
    const first = data[0].value;
    const last = data[data.length - 1].value;
    return ((last - first) / first) * 100;
  };

  const change = calculateChange();
  const isPositive = change > 0;
  const isNeutral = change === 0;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-900/90 backdrop-blur-sm p-3 rounded-lg border border-gray-700/50 shadow-xl">
          <p className="text-sm text-gray-300">{label}</p>
          <p className="text-lg font-bold text-white">
            ${payload[0].value.toFixed(2)}
          </p>
          <p className={`text-sm ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
            {isPositive ? '+' : ''}{change.toFixed(2)}%
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-white">{title}</h3>
          <div className="flex items-center space-x-2 mt-1">
            <span className="text-2xl font-bold text-white">
              ${data[data.length - 1]?.value.toFixed(2) || '0.00'}
            </span>
            {showChange && (
              <div className={`flex items-center px-2 py-1 rounded-md ${
                isPositive ? 'bg-emerald-500/20 text-emerald-400' :
                isNeutral ? 'bg-gray-700/50 text-gray-400' :
                'bg-red-500/20 text-red-400'
              }`}>
                {isPositive ? <TrendingUp className="w-3 h-3 mr-1" /> :
                 isNeutral ? <Minus className="w-3 h-3 mr-1" /> :
                 <TrendingDown className="w-3 h-3 mr-1" />}
                <span className="text-sm font-medium">
                  {isPositive ? '+' : ''}{change.toFixed(2)}%
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="flex space-x-2">
          {(['1d', '1w', '1m', '3m'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                timeRange === range
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-700/50 text-gray-400 hover:bg-gray-700'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
            <defs>
              <linearGradient id={`gradient-${title}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
            <XAxis 
              dataKey="time" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: '#9CA3AF', fontSize: 12 }}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fill: '#9CA3AF', fontSize: 12 }}
              domain={['dataMin - 10', 'dataMax + 10']}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="value"
              stroke={color}
              strokeWidth={2}
              fill={`url(#gradient-${title})`}
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* 技术指标 */}
      <div className="grid grid-cols-3 gap-4 mt-6