# 多智能体股市监测系统 - 数据使用指南

## 概述

本系统支持使用真实股票数据进行智能体分析。系统提供了多种数据获取方式，从简单的测试数据到真实的网络数据。

## 数据文件结构

系统使用以下JSON数据文件：

### 1. 价格历史数据 (`data/price_history.json`)
```json
{
  "last_updated": "2026-03-15",
  "companies": [
    {
      "ticker": "AAPL",
      "name": "Apple Inc.",
      "price_history": [
        {
          "date": "2026-03-01",
          "open": 175.50,
          "high": 177.20,
          "low": 174.80,
          "close": 176.80,
          "volume": 45678900
        },
        // ... 更多价格数据
      ]
    }
  ]
}
```

### 2. 公司财务数据 (`data/company_financials.json`)
```json
{
  "last_updated": "2026-03-15",
  "companies": [
    {
      "ticker": "AAPL",
      "name": "Apple Inc.",
      "sector": "Technology",
      "industry": "Consumer Electronics",
      "financials": {
        "revenue": 383285000000,
        "gross_profit": 169148000000,
        "net_income": 96995000000,
        // ... 更多财务数据
      },
      "key_metrics": {
        "market_cap": 2760000000000,
        "dividend_yield": 0.52,
        "beta": 1.28
      }
    }
  ]
}
```

### 3. 市场概况数据 (`data/market_overview.json`)
```json
{
  "timestamp": "2026-03-15T18:50:53.123456",
  "market_overview": {
    "market_condition": "neutral",
    "risk_level": "medium",
    "major_indices": {
      "sp500": {
        "value": 5200.45,
        "change": 15.32,
        "change_percent": 0.30,
        "trend": "up"
      }
    },
    // ... 更多市场数据
  }
}
```

## 数据获取方式

### 方式1: 使用现有数据（默认）
系统已经包含了三个公司的模拟数据：
- **AAPL** (Apple Inc.)
- **TSLA** (Tesla Inc.)
- **BABA** (Alibaba Group)

这些数据是基于真实数据的合理模拟，适合测试和演示。

### 方式2: 生成新的测试数据
使用数据获取工具生成更多公司的测试数据：

```bash
# 生成测试数据（10家公司）
python data_fetcher.py --mode test

# 只生成指定公司的数据
python data_fetcher.py --mode test --companies AAPL TSLA MSFT
```

支持的测试公司：
- AAPL, TSLA, BABA (已有详细数据)
- MSFT, GOOGL, AMZN, NVDA, META, JPM, V (生成模拟数据)

### 方式3: 从网络获取真实数据
尝试从Yahoo Finance等公开API获取真实数据：

```bash
# 尝试获取真实数据（需要网络连接）
python data_fetcher.py --mode test --real-api

# 获取完整数据集
python data_fetcher.py --mode full --real-api
```

**注意**: 公开API可能有速率限制，且财务数据通常需要付费API才能获取完整信息。

## 数据获取工具 (`data_fetcher.py`)

### 功能特性
1. **多数据源支持**: Yahoo Finance, Alpha Vantage（需要API密钥）
2. **智能回退**: 当API失败时自动生成合理的模拟数据
3. **批量处理**: 支持多公司批量获取
4. **数据验证**: 检查数据完整性和合理性

### 使用方法

```bash
# 查看帮助
python data_fetcher.py --help

# 创建测试数据集（默认）
python data_fetcher.py --mode test

# 创建完整数据集
python data_fetcher.py --mode full

# 使用真实API获取数据
python data_fetcher.py --mode test --real-api

# 只获取指定公司的数据
python data_fetcher.py --mode test --companies AAPL TSLA MSFT
```

### 数据源说明

#### Yahoo Finance API
- **免费**: 是
- **速率限制**: 有，但较宽松
- **数据范围**: 价格历史、基本指标
- **财务数据**: 有限，需要解析财报

#### Alpha Vantage API
- **免费**: 是（有每日限制）
- **需要注册**: 是（获取API密钥）
- **数据范围**: 价格、技术指标、基本面
- **财务数据**: 较完整

## 智能体如何使用数据

### 1. 宏观分析智能体
- 使用市场概况数据 (`market_overview.json`)
- 分析整体市场趋势
- 评估经济指标
- 识别行业表现

### 2. 个股研究智能体
- 使用公司财务数据 (`company_financials.json`)
- 分析财务比率
- 评估盈利能力
- 计算估值指标

### 3. 交易策略智能体
- 使用价格历史数据 (`price_history.json`)
- 技术分析
- 识别交易信号
- 计算支撑阻力位

### 4. 执行监控智能体
- 综合所有数据
- 风险评估
- 监控执行条件
- 预警系统

### 5. 总指挥智能体
- 协调所有智能体
- 整合分析结果
- 生成综合建议
- 决策支持

## 数据质量要求

### 必需字段
1. **价格数据**: date, open, high, low, close, volume
2. **财务数据**: revenue, net_income, total_assets, equity
3. **市场数据**: market_condition, major_indices

### 数据验证
系统会自动验证：
- 数据完整性
- 数值合理性（如价格不为负）
- 时间序列连续性
- 财务比率逻辑性

## 扩展数据源

### 添加新的数据源
1. 在 `data_fetcher.py` 中添加新的数据获取方法
2. 实现数据解析和格式化
3. 添加错误处理和回退机制

### 示例：添加新的API
```python
def fetch_data_from_new_api(self, ticker: str):
    """从新的API获取数据"""
    try:
        # 实现API调用
        response = requests.get(f"https://api.example.com/{ticker}")
        data = response.json()
        
        # 解析和格式化数据
        formatted_data = self._format_data(data)
        
        return formatted_data
    except Exception as e:
        logger.error(f"从新API获取数据失败: {e}")
        return self._generate_sample_data(ticker)
```

## 数据更新策略

### 定期更新
建议定期更新数据以保持分析准确性：
- **价格数据**: 每日更新
- **财务数据**: 季度更新（财报发布后）
- **市场数据**: 每日更新

### 增量更新
对于大量数据，建议使用增量更新：
```python
def update_incremental(self, ticker: str, last_update: datetime):
    """增量更新数据"""
    # 只获取上次更新后的数据
    new_data = self.fetch_recent_data(ticker, since=last_update)
    
    # 合并到现有数据
    existing_data = self.load_existing_data(ticker)
    updated_data = self.merge_data(existing_data, new_data)
    
    return updated_data
```

## 故障排除

### 常见问题

#### 1. API请求失败
- **症状**: 获取数据时超时或返回错误
- **解决方案**: 
  - 检查网络连接
  - 降低请求频率
  - 使用备用数据源
  - 启用模拟数据回退

#### 2. 数据格式错误
- **症状**: 智能体分析时出现异常
- **解决方案**:
  - 验证数据文件格式
  - 检查必需字段是否存在
  - 验证数值范围是否合理

#### 3. 数据不完整
- **症状**: 某些公司或时间段数据缺失
- **解决方案**:
  - 重新获取数据
  - 使用数据插值
  - 排除不完整的数据

#### 4. 性能问题
- **症状**: 数据加载或分析缓慢
- **解决方案**:
  - 优化数据文件大小
  - 使用数据缓存
  - 分批处理数据

## 最佳实践

### 数据管理
1. **版本控制**: 保留历史数据版本
2. **备份**: 定期备份数据文件
3. **验证**: 更新后验证数据质量
4. **文档**: 记录数据来源和更新历史

### 性能优化
1. **压缩**: 对大文件使用压缩
2. **索引**: 对常用查询字段建立索引
3. **缓存**: 缓存频繁访问的数据
4. **分批**: 大数据集分批处理

### 安全性
1. **API密钥**: 不要将API密钥提交到版本控制
2. **数据脱敏**: 生产环境使用脱敏数据
3. **访问控制**: 限制数据访问权限
4. **审计日志**: 记录数据访问和修改

## 示例：使用真实数据进行智能体分析

### 步骤1: 获取数据
```bash
python data_fetcher.py --mode test --real-api --companies AAPL TSLA MSFT
```

### 步骤2: 启动系统
```bash
start_with_data.bat
```

### 步骤3: 进行分析
1. 打开前端页面
2. 选择公司（如AAPL）
3. 点击"开始分析"或"快速分析"
4. 查看各智能体的分析结果

### 步骤4: 查看结果
- **宏观分析**: 市场环境评估
- **财务分析**: 公司财务状况
- **技术分析**: 交易信号和建议
- **风险监控**: 执行风险评估
- **综合建议**: 总体投资建议

## 结论

通过使用真实或模拟的真实数据，多智能体系统能够提供更有价值的分析结果。系统设计灵活，支持多种数据源和更新策略，可以根据需要扩展和定制。

**重要提示**: 本系统仅供学习和研究使用。投资有风险，决策需谨慎。