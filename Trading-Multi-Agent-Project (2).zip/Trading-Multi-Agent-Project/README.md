# 多智能体股市监测系统

基于OpenClaw框架的五智能体协作股市监测与决策系统。

## 🎯 项目概述

本项目是一个基于OpenClaw框架的多智能体股市监测系统，通过五个专业智能体的协作，为投资者提供全面的股市分析、投资建议和风险监控服务。

### 核心特点
- **五智能体协作架构**：Orchestrator、Macro、Research、Trading、Executor五个智能体协同工作
- **本地数据支持**：完全使用本地模拟数据，无需外部API
- **专业金融分析**：宏观、基本面、技术面、风险多维度分析
- **完整前后端**：包含后端分析引擎和现代化前端界面
- **详细文档**：完整的实施方案、使用手册和集成指南

## 🏗️ 系统架构

### 智能体架构
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Orchestrator  │    │     Macro       │    │    Research     │
│   总指挥智能体   │◄──►│  宏观分析智能体  │◄──►│  个股研究智能体  │
│                 │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│    Trading      │    │    Executor     │    │   Data Sources  │
│  交易策略智能体   │◄──►│  执行监控智能体  │◄──►│   本地数据源     │
│                 │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### 技术栈
- **后端**: Python 3.8+, FastAPI, OpenClaw框架
- **前端**: React 18, TypeScript, Tailwind CSS
- **数据**: 本地JSON文件，模拟真实市场数据
- **通信**: REST API + WebSocket实时通信

## 📁 项目结构

```
F:\Programming\Trading-Multi-Agent-Project\
├── 📄 README.md                          # 项目说明文档
├── 📄 main.py                            # 主程序入口
├── 📄 requirements.txt                   # Python依赖
├── 📄 openclaw.json                      # OpenClaw配置文件
├── 📄 multi_agent_stock_advisor_plan.txt # 完整实施方案
├── 📄 frontend_architecture.md          # 前端架构设计
├── 📄 frontend_components.md            # 前端组件示例
├── 📄 user_manual.md                    # 使用手册
├── 📄 integration_guide.md              # 前后端整合指南
├── 📁 agents/                           # 智能体目录
│   ├── orchestrator/                    # 总指挥智能体
│   │   └── agent.md                     # 智能体定义
│   ├── macro/                           # 宏观分析智能体
│   │   └── agent.md                     # 智能体定义
│   ├── research/                        # 个股研究智能体
│   │   └── agent.md                     # 智能体定义
│   ├── trading/                         # 交易策略智能体
│   │   └── agent.md                     # 智能体定义
│   └── executor/                        # 执行监控智能体
│       └── agent.md                     # 智能体定义
├── 📁 data/                             # 本地数据目录
│   ├── market_overview.json             # 市场宏观数据
│   ├── company_financials.json          # 公司财务数据
│   └── price_history.json               # 历史价格数据
└── 📁 logs/                             # 日志目录（运行时创建）
```

## 🚀 快速开始

### 环境要求
- Python 3.8+
- Node.js 16+（前端开发）
- 8GB RAM（推荐16GB）

### 安装步骤

#### 1. 克隆项目
```bash
git clone <项目地址>
cd Trading-Multi-Agent-Project
```

#### 2. 安装Python依赖
```bash
# 创建虚拟环境
python -m venv venv

# 激活虚拟环境
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt
```

#### 3. 运行系统
```bash
# 启动后端服务
python main.py
```

### 使用示例
系统启动后，按照提示操作：
```
1. 分析单个公司（如AAPL、TSLA、BABA）
2. 批量分析多个公司
3. 查看系统状态
4. 退出系统
```

## 📊 核心功能

### 1. 智能体协作分析
- **Orchestrator**: 协调工作流，整合结果
- **Macro Agent**: 分析宏观经济和市场趋势
- **Research Agent**: 深度财务分析和基本面评估
- **Trading Agent**: 技术分析和交易策略制定
- **Executor Agent**: 风险监控和执行评估

### 2. 数据分析维度
- **宏观分析**: 市场整体趋势、行业表现、经济指标
- **基本面分析**: 财务比率、盈利能力、偿债能力
- **技术分析**: 移动平均线、价格趋势、交易信号
- **风险评估**: 风险等级、监控要点、控制建议

### 3. 报告生成
- **多种格式**: Markdown、JSON、HTML
- **完整内容**: 分析摘要、详细数据、投资建议
- **专业展示**: 图表可视化、数据表格、风险提示

## 🔧 配置说明

### OpenClaw配置
系统使用`openclaw.json`进行配置，主要配置项包括：
- **智能体配置**: 各智能体的参数和行为
- **工作流配置**: 不同分析类型的工作流程
- **数据源配置**: 本地数据文件的路径和更新频率
- **API配置**: 后端服务的端口和CORS设置

### 数据配置
系统使用三个核心数据文件：
1. `data/market_overview.json` - 市场宏观数据
2. `data/company_financials.json` - 公司财务数据
3. `data/price_history.json` - 历史价格数据

## 📈 数据示例

### 支持的公司
系统预置了三个示例公司的完整数据：
- **AAPL** (Apple Inc.) - 科技行业
- **TSLA** (Tesla Inc.) - 汽车行业
- **BABA** (Alibaba Group) - 电商行业

### 分析结果示例
```json
{
  "ticker": "AAPL",
  "analysis_type": "full",
  "overall_score": 78.5,
  "risk_level": "中等风险",
  "summary": "宏观: 中性持有 | 基本面: 买入 | 技术面: 买入 | 风险: 中等风险",
  "recommendations": [
    "宏观策略: 中性持有",
    "投资建议: 买入",
    "交易策略: 买入",
    "风险控制: 控制单笔交易规模"
  ]
}
```

## 🎨 前端界面

### 设计特点
- **金融科技风格**: 深色主题，专业配色
- **数据可视化**: 丰富的图表和交互组件
- **实时更新**: WebSocket实时数据推送
- **响应式设计**: 支持桌面和移动设备

### 核心页面
1. **仪表板**: 市场概览、智能体状态、关键指标
2. **分析页面**: 公司选择、多维度分析结果
3. **报告中心**: 历史报告查看和导出
4. **设置中心**: 系统配置和用户偏好

## 🔌 API接口

### 核心端点
- `GET /api/market/overview` - 获取市场概览
- `POST /api/analysis/single` - 单公司分析
- `POST /api/analysis/batch` - 批量分析
- `GET /api/agents/status` - 获取智能体状态
- `POST /api/reports/generate` - 生成报告

### WebSocket接口
- `ws://localhost:8000/ws` - 实时数据推送
- 支持市场数据、智能体状态、分析进度等实时更新

## 🛠️ 开发指南

### 扩展智能体
1. 在`agents/`目录下创建新的智能体目录
2. 创建`agent.md`文件定义智能体角色和工具
3. 在`openclaw.json`中注册新的智能体
4. 实现相应的Python工具类

### 添加新数据
1. 在`data/`目录下创建新的JSON数据文件
2. 更新`openclaw.json`中的数据源配置
3. 在`DataLoader`类中添加数据加载方法

### 自定义分析逻辑
1. 修改相应智能体的`analyze`方法
2. 添加新的技术指标或财务比率计算
3. 调整分析权重和评分算法

## 📚 文档资源

### 核心文档
1. **实施方案**: `multi_agent_stock_advisor_plan.txt`
2. **使用手册**: `user_manual.md`
3. **前端架构**: `frontend_architecture.md`
4. **整合指南**: `integration_guide.md`

### 智能体文档
- `agents/orchestrator/agent.md` - 总指挥智能体
- `agents/macro/agent.md` - 宏观分析智能体
- `agents/research/agent.md` - 个股研究智能体
- `agents/trading/agent.md` - 交易策略智能体
- `agents/executor/agent.md` - 执行监控智能体

## 🔍 故障排除

### 常见问题

#### 1. 系统无法启动
```
可能原因: 依赖未安装或端口被占用
解决方案:
1. 检查Python依赖: pip install -r requirements.txt
2. 检查端口占用: netstat -ano | findstr :8000
3. 检查配置文件: 确保openclaw.json配置正确
```

#### 2. 数据分析错误
```
可能原因: 数据文件缺失或格式错误
解决方案:
1. 检查数据文件: 确保data/目录下文件完整
2. 验证数据格式: 确保JSON文件格式正确
3. 查看日志: 检查logs/system.log中的错误信息
```

#### 3. 内存不足
```
可能原因: 同时分析过多公司
解决方案:
1. 减少批量分析的数量
2. 增加系统内存
3. 调整分析深度参数
```

### 日志查看
```bash
# 查看实时日志
tail -f logs/system.log

# 查看错误日志
cat logs/error.log
```

## 📞 技术支持

### 获取帮助
- **文档**: 查看项目中的详细文档
- **日志**: 检查系统日志获取详细信息
- **测试**: 使用预置的示例数据进行测试

### 报告问题
1. 查看日志文件获取错误信息
2. 描述复现步骤和预期行为
3. 提供系统环境信息

## 📄 许可证

本项目仅供学习和研究使用。投资有风险，决策需谨慎。

## 🚧 开发路线图

### 已完成
- ✅ 五智能体协作架构设计
- ✅ 本地数据模拟系统
- ✅ 核心分析引擎实现
- ✅ 完整文档和配置

### 计划中
- 🔄 前端界面实现
- 🔄 实时数据更新
- 🔄 更多技术指标
- 🔄 高级预警系统

## 🤝 贡献指南

欢迎贡献代码、报告问题或提出建议！

1. Fork项目
2. 创建功能分支
3. 提交更改
4. 创建Pull Request

---

**最后更新**: 2026年3月15日  
**版本**: v1.0.0  
**作者**: 多智能体股市监测系统团队