@echo off
echo ========================================
echo 多智能体股市监测系统启动脚本
echo ========================================
echo.

REM 检查Python是否安装
python --version >nul 2>&1
if errorlevel 1 (
    echo 错误: 未找到Python，请先安装Python 3.8+
    pause
    exit /b 1
)

REM 检查依赖是否安装
echo 检查Python依赖...
pip list | findstr "fastapi" >nul
if errorlevel 1 (
    echo 安装依赖...
    pip install -r requirements.txt
) else (
    echo 依赖已安装
)

REM 创建必要的目录
echo 创建必要的目录...
if not exist "logs" mkdir logs
if not exist "data" mkdir data

REM 检查数据文件是否存在
echo 检查数据文件...
if not exist "data\company_financials.json" (
    echo 警告: 未找到公司财务数据文件
    echo 请确保 data\company_financials.json 存在
)

if not exist "data\market_overview.json" (
    echo 警告: 未找到市场概况数据文件
    echo 请确保 data\market_overview.json 存在
)

if not exist "data\price_history.json" (
    echo 警告: 未找到价格历史数据文件
    echo 请确保 data\price_history.json 存在
)

echo.
echo ========================================
echo 启动API服务器...
echo API地址: http://localhost:8000
echo 文档地址: http://localhost:8000/docs
echo ========================================
echo.

REM 启动API服务器
start cmd /k "python api_server.py"

echo.
echo ========================================
echo 启动前端页面...
echo 前端地址: file:///%CD%/frontend/index.html
echo ========================================
echo.

REM 打开前端页面
start "" "frontend\index.html"

echo 系统已启动！
echo 请访问:
echo 1. API服务器: http://localhost:8000
echo 2. API文档: http://localhost:8000/docs
echo 3. 前端页面: file:///%CD%/frontend/index.html
echo.
echo 按任意键退出...
pause >nul