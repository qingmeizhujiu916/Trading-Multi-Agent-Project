#!/usr/bin/env python3
"""
项目完整性检查
"""

import os
import json
import sys
from pathlib import Path

def check_directory_structure():
    """检查目录结构"""
    print("检查目录结构...")
    
    required_dirs = [
        "agents",
        "data",
        "logs"
    ]
    
    required_files = [
        "main.py",
        "README.md",
        "requirements.txt",
        "openclaw.json",
        "data/market_overview.json",
        "data/company_financials.json",
        "data/price_history.json"
    ]
    
    all_good = True
    
    # 检查目录
    for dir_name in required_dirs:
        if os.path.exists(dir_name) and os.path.isdir(dir_name):
            print(f"✓ 目录存在: {dir_name}")
        else:
            print(f"✗ 目录缺失: {dir_name}")
            all_good = False
    
    # 检查文件
    for file_name in required_files:
        if os.path.exists(file_name):
            print(f"✓ 文件存在: {file_name}")
        else:
            print(f"✗ 文件缺失: {file_name}")
            all_good = False
    
    return all_good

def check_data_files():
    """检查数据文件格式"""
    print("\n检查数据文件格式...")
    
    data_files = [
        ("data/market_overview.json", "market_overview"),
        ("data/company_financials.json", "companies"),
        ("data/price_history.json", "companies")
    ]
    
    all_good = True
    
    for file_path, required_key in data_files:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if required_key == "market_overview":
                if "market_overview" in data:
                    print(f"✓ {file_path} 格式正确")
                else:
                    print(f"✗ {file_path} 缺少'market_overview'字段")
                    all_good = False
            elif required_key == "companies":
                if "companies" in data and isinstance(data["companies"], list):
                    print(f"✓ {file_path} 格式正确 ({len(data['companies'])} 家公司)")
                else:
                    print(f"✗ {file_path} 缺少'companies'字段或格式错误")
                    all_good = False
                    
        except json.JSONDecodeError as e:
            print(f"✗ {file_path} JSON格式错误: {e}")
            all_good = False
        except Exception as e:
            print(f"✗ {file_path} 读取错误: {e}")
            all_good = False
    
    return all_good

def check_agent_files():
    """检查智能体文件"""
    print("\n检查智能体文件...")
    
    agent_dirs = [
        "agents/orchestrator",
        "agents/macro",
        "agents/research",
        "agents/trading",
        "agents/executor"
    ]
    
    all_good = True
    
    for agent_dir in agent_dirs:
        agent_file = os.path.join(agent_dir, "agent.md")
        if os.path.exists(agent_file):
            print(f"✓ 智能体文件存在: {agent_file}")
        else:
            print(f"✗ 智能体文件缺失: {agent_file}")
            all_good = False
    
    return all_good

def check_code_imports():
    """检查代码导入"""
    print("\n检查代码导入...")
    
    try:
        # 尝试导入主要模块
        import sys
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        from main import DataLoader, MacroAgent, ResearchAgent, TradingAgent, ExecutorAgent, Orchestrator
        
        print("✓ 主要类导入成功")
        
        # 测试DataLoader实例化
        data_loader = DataLoader()
        print("✓ DataLoader实例化成功")
        
        return True
        
    except ImportError as e:
        print(f"✗ 导入错误: {e}")
        return False
    except Exception as e:
        print(f"✗ 实例化错误: {e}")
        return False

def check_config_files():
    """检查配置文件"""
    print("\n检查配置文件...")
    
    config_files = [
        "openclaw.json",
        "requirements.txt"
    ]
    
    all_good = True
    
    for config_file in config_files:
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                if config_file == "openclaw.json":
                    json.loads(content)  # 验证JSON格式
                    print(f"✓ {config_file} JSON格式正确")
                elif config_file == "requirements.txt":
                    lines = [line.strip() for line in content.split('\n') if line.strip() and not line.startswith('#')]
                    print(f"✓ {config_file} 包含 {len(lines)} 个依赖项")
                    
            except json.JSONDecodeError as e:
                print(f"✗ {config_file} JSON格式错误: {e}")
                all_good = False
            except Exception as e:
                print(f"✗ {config_file} 读取错误: {e}")
                all_good = False
        else:
            print(f"✗ 配置文件缺失: {config_file}")
            all_good = False
    
    return all_good

def generate_summary():
    """生成项目摘要"""
    print("\n" + "="*60)
    print("项目摘要")
    print("="*60)
    
    # 统计文件
    total_files = 0
    total_size = 0
    
    for root, dirs, files in os.walk("."):
        # 跳过一些目录
        if any(skip in root for skip in [".git", "__pycache__", ".venv"]):
            continue
            
        for file in files:
            if file.endswith(('.py', '.md', '.json', '.txt')):
                file_path = os.path.join(root, file)
                total_files += 1
                total_size += os.path.getsize(file_path)
    
    print(f"项目文件总数: {total_files}")
    print(f"项目总大小: {total_size / 1024:.1f} KB")
    
    # 列出主要文件
    print("\n主要文件:")
    main_files = [
        "main.py",
        "README.md",
        "requirements.txt",
        "openclaw.json",
        "test_runner.py",
        "install_dependencies.py",
        "project_check.py"
    ]
    
    for file in main_files:
        if os.path.exists(file):
            size = os.path.getsize(file)
            print(f"  {file}: {size} bytes")
    
    # 数据统计
    print("\n数据统计:")
    try:
        with open("data/company_financials.json", 'r', encoding='utf-8') as f:
            companies_data = json.load(f)
            print(f"  公司数量: {len(companies_data.get('companies', []))}")
    except:
        print("  公司数据: 无法读取")
    
    try:
        with open("data/price_history.json", 'r', encoding='utf-8') as f:
            price_data = json.load(f)
            total_records = 0
            for company in price_data.get('companies', []):
                total_records += len(company.get('price_history', []))
            print(f"  价格记录总数: {total_records}")
    except:
        print("  价格数据: 无法读取")

def main():
    """主函数"""
    print("="*60)
    print("多智能体股市监测系统 - 项目完整性检查")
    print("="*60)
    
    checks = [
        ("目录结构", check_directory_structure),
        ("数据文件", check_data_files),
        ("智能体文件", check_agent_files),
        ("代码导入", check_code_imports),
        ("配置文件", check_config_files),
    ]
    
    all_passed = True
    for check_name, check_func in checks:
        print(f"\n{check_name}:")
        if not check_func():
            all_passed = False
    
    # 生成摘要
    generate_summary()
    
    print("\n" + "="*60)
    if all_passed:
        print("✓ 所有检查通过!")
        print("项目完整性良好，可以正常运行。")
    else:
        print("✗ 部分检查未通过!")
        print("请修复上述问题后再运行项目。")
    
    print("="*60)
    
    return all_passed

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)