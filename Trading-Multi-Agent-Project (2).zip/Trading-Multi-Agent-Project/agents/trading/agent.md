# Trading Agent - 交易策略智能体

## 角色描述
负责分析技术指标、价格趋势和市场微观结构，制定具体的交易策略和进出场时机。

## 核心职责
1. 分析价格趋势和技术形态
2. 计算技术指标和交易信号
3. 评估市场流动性和波动性
4. 制定具体的交易策略
5. 确定进出场时机和风险管理

## 工具定义

### 工具1：分析价格趋势
```python
def analyze_price_trend(price_data: list) -> dict:
    """
    分析价格趋势
    
    参数:
        price_data: 价格数据列表，每个元素包含date, open, high, low, close, volume
    
    返回:
        趋势分析结果
    """
    if not price_data or len(price_data) < 10:
        return {"error": "数据不足，至少需要10个交易日数据"}
    
    # 提取收盘价
    closes = [p["close"] for p in price_data]
    dates = [p["date"] for p in price_data]
    
    analysis = {
        "trend_direction": "sideways",
        "trend_strength": 0,
        "support_levels": [],
        "resistance_levels": [],
        "current_price": closes[-1],
        "price_change_percent": 0,
        "volatility": 0
    }
    
    # 计算价格变化
    if len(closes) >= 2:
        price_change = ((closes[-1] - closes[-2]) / closes[-2]) * 100
        analysis["price_change_percent"] = price_change
    
    # 计算移动平均线
    if len(closes) >= 5:
        ma5 = sum(closes[-5:]) / 5
        analysis["ma5"] = ma5
    
    if len(closes) >= 10:
        ma10 = sum(closes[-10:]) / 10
        analysis["ma10"] = ma10
    
    if len(closes) >= 20:
        ma20 = sum(closes[-20:]) / 20
        analysis["ma20"] = ma20
    
    # 判断趋势方向
    if "ma5" in analysis and "ma10" in analysis:
        if analysis["ma5"] > analysis["ma10"] and analysis["ma10"] > analysis.get("ma20", analysis["ma10"]):
            analysis["trend_direction"] = "uptrend"
        elif analysis["ma5"] < analysis["ma10"] and analysis["ma10"] < analysis.get("ma20", analysis["ma10"]):
            analysis["trend_direction"] = "downtrend"
    
    # 计算趋势强度
    if len(closes) >= 20:
        recent_prices = closes[-20:]
        price_range = max(recent_prices) - min(recent_prices)
        if price_range > 0:
            current_position = (closes[-1] - min(recent_prices)) / price_range
            analysis["trend_strength"] = abs(current_position - 0.5) * 2  # 0-1范围
    
    # 计算波动性（20日标准差）
    if len(closes) >= 20:
        recent_closes = closes[-20:]
        mean_price = sum(recent_closes) / len(recent_closes)
        variance = sum((x - mean_price) ** 2 for x in recent_closes) / len(recent_closes)
        analysis["volatility"] = variance ** 0.5
    
    # 识别支撑阻力位（简化版）
    if len(closes) >= 20:
        recent_highs = [p["high"] for p in price_data[-20:]]
        recent_lows = [p["low"] for p in price_data[-20:]]
        
        # 简单的支撑阻力识别
        analysis["resistance_levels"] = [max(recent_highs)]
        analysis["support_levels"] = [min(recent_lows)]
    
    return analysis
```

### 工具2：生成技术信号
```python
def generate_technical_signals(price_data: list, trend_analysis: dict) -> dict:
    """
    生成技术交易信号
    
    参数:
        price_data: 价格数据
        trend_analysis: 趋势分析结果
    
    返回:
        技术信号
    """
    signals = {
        "moving_average_signals": [],
        "momentum_signals": [],
        "volume_signals": [],
        "pattern_signals": [],
        "overall_signal": "neutral",
        "signal_strength": 0
    }
    
    if not price_data or len(price_data) < 10:
        return signals
    
    closes = [p["close"] for p in price_data]
    volumes = [p["volume"] for p in price_data]
    current_price = closes[-1]
    
    # 移动平均线信号
    if len(closes) >= 10:
        ma5 = sum(closes[-5:]) / 5
        ma10 = sum(closes[-10:]) / 10
        
        if current_price > ma5 and ma5 > ma10:
            signals["moving_average_signals"].append("金叉信号：短期均线上穿长期均线")
            signals["overall_signal"] = "bullish"
            signals["signal_strength"] += 0.3
        elif current_price < ma5 and ma5 < ma10:
            signals["moving_average_signals"].append("死叉信号：短期均线下穿长期均线")
            signals["overall_signal"] = "bearish"
            signals["signal_strength"] += 0.3
    
    # 动量信号（RSI简化版）
    if len(closes) >= 14:
        gains = []
        losses = []
        
        for i in range(1, 15):
            change = closes[-i] - closes[-i-1] if len(closes) > i else 0
            if change > 0:
                gains.append(change)
            else:
                losses.append(abs(change))
        
        avg_gain = sum(gains) / len(gains) if gains else 0
        avg_loss = sum(losses) / len(losses) if losses else 0
        
        if avg_loss > 0:
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            if rsi > 70:
                signals["momentum_signals"].append("RSI超买：可能回调")
                if signals["overall_signal"] == "bullish":
                    signals["signal_strength"] -= 0.2
            elif rsi < 30:
                signals["momentum_signals"].append("RSI超卖：可能反弹")
                if signals["overall_signal"] == "bearish":
                    signals["signal_strength"] -= 0.2
    
    # 成交量信号
    if len(volumes) >= 5:
        avg_volume = sum(volumes[-5:]) / 5
        current_volume = volumes[-1]
        
        if current_volume > avg_volume * 1.5:
            volume_signal = "放量"
            if trend_analysis.get("trend_direction") == "uptrend":
                signals["volume_signals"].append(f"{volume_signal}上涨，趋势可能延续")
                signals["signal_strength"] += 0.2
            elif trend_analysis.get("trend_direction") == "downtrend":
                signals["volume_signals"].append(f"{volume_signal}下跌，趋势可能延续")
                signals["signal_strength"] += 0.2
    
    # 价格模式信号（简化版）
    if len(closes) >= 5:
        # 检查是否形成更高的高点和低点（上升趋势）
        if (closes[-1] > closes[-3] and closes[-3] > closes[-5] and
            min(closes[-5:-2]) < min(closes[-2:])):
            signals["pattern_signals"].append("形成更高的高点和低点，上升趋势确认")
            if signals["overall_signal"] != "bearish":
                signals["overall_signal"] = "bullish"
                signals["signal_strength"] += 0.3
        
        # 检查是否形成更低的高点和低点（下降趋势）
        elif (closes[-1] < closes[-3] and closes[-3] < closes[-5] and
              max(closes[-5:-2]) > max(closes[-2:])):
            signals["pattern_signals"].append("形成更低的高点和低点，下降趋势确认")
            if signals["overall_signal"] != "bullish":
                signals["overall_signal"] = "bearish"
                signals["signal_strength"] += 0.3
    
    # 限制信号强度在0-1范围内
    signals["signal_strength"] = max(0, min(1, signals["signal_strength"]))
    
    return signals
```

### 工具3：制定交易策略
```python
def generate_trading_strategy(trend_analysis: dict, technical_signals: dict, 
                             risk_tolerance: str = "medium") -> dict:
    """
    制定交易策略
    
    参数:
        trend_analysis: 趋势分析结果
        technical_signals: 技术信号
        risk_tolerance: 风险承受能力（low/medium/high）
    
    返回:
        交易策略
    """
    strategy = {
        "entry_signal": "wait",
        "exit_signal": "hold",
        "position_size": "standard",
        "stop_loss_level": 0,
        "take_profit_levels": [],
        "timeframe": "intraday",
        "confidence": technical_signals.get("signal_strength", 0)
    }
    
    current_price = trend_analysis.get("current_price", 0)
    trend_direction = trend_analysis.get("trend_direction", "sideways")
    overall_signal = technical_signals.get("overall_signal", "neutral")
    
    # 根据趋势和信号确定入场信号
    if overall_signal == "bullish" and trend_direction in ["uptrend", "sideways"]:
        strategy["entry_signal"] = "buy"
        
        # 设置止损位
        support_levels = trend_analysis.get("support_levels", [])
        if support_levels:
            stop_loss = min(support_levels)
            if stop_loss < current_price:
                strategy["stop_loss_level"] = stop_loss
                stop_loss_percent = ((current_price - stop_loss) / current_price) * 100
                
                # 根据风险承受能力调整止损
                if risk_tolerance == "low":
                    if stop_loss_percent > 3:
                        strategy["stop_loss_level"] = current_price * 0.97
                elif risk_tolerance == "high":
                    if stop_loss_percent > 8:
                        strategy["stop_loss_level"] = current_price * 0.92
        
        # 设置止盈位
        resistance_levels = trend_analysis.get("resistance_levels", [])
        if resistance_levels:
            take_profit = max(resistance_levels)
            if take_profit > current_price:
                strategy["take_profit_levels"] = [
                    current_price + (take_profit - current_price) * 0.5,
                    take_profit
                ]
    
    elif overall_signal == "bearish" and trend_direction in ["downtrend", "sideways"]:
        strategy["entry_signal"] = "sell"
        
        # 对于卖空，止损位在阻力位上方
        resistance_levels = trend_analysis.get("resistance_levels", [])
        if resistance_levels:
            stop_loss = max(resistance_levels)
            if stop_loss > current_price:
                strategy["stop_loss_level"] = stop_loss
        
        # 卖空止盈位在支撑位
        support_levels = trend_analysis.get("support_levels", [])
        if support_levels:
            take_profit = min(support_levels)
            if take_profit < current_price:
                strategy["take_profit_levels"] = [
                    current_price - (current_price - take_profit) * 0.5,
                    take_profit
                ]
    
    # 根据信心度调整仓位大小
    confidence = strategy["confidence"]
    if confidence > 0.8:
        strategy["position_size"] = "aggressive"
        strategy["timeframe"] = "swing"  # 摆动交易
    elif confidence > 0.6:
        strategy["position_size"] = "standard"
        strategy["timeframe"] = "intraday"  # 日内交易
    else:
        strategy["position_size"] = "conservative"
        strategy["timeframe"] = "scalp"  #  scalp交易
    
    # 根据风险承受能力调整
    if risk_tolerance == "low":
        strategy["position_size"] = "conservative"
        if strategy["stop_loss_level"] and strategy["stop_loss_level"] > 0:
            # 收紧止损
            if strategy["entry_signal"] == "buy":
                strategy["stop_loss_level"] = max(strategy["stop_loss_level"], current_price * 0.98)
            elif strategy["entry_signal"] == "sell":
                strategy["stop_loss_level"] = min(strategy["stop_loss_level"], current_price * 1.02)
    
    elif risk_tolerance == "high":
        if strategy["position_size"] == "conservative":
            strategy["position_size"] = "standard"
    
    return strategy
```

### 工具4：生成交易建议
```python
def generate_trading_recommendation(trend_analysis: dict, technical_signals: dict, 
                                   trading_strategy: dict) -> dict:
    """
    生成交易建议
    
    参数:
        trend_analysis: 趋势分析
        technical_signals: 技术信号
        trading_strategy: 交易策略
    
    返回:
        交易建议
    """
    recommendation = {
        "action": "hold",
        "recommendation": "观望",
        "confidence": trading_strategy.get("confidence", 0),
        "reasoning": [],
        "risk_level": "medium",
        "time_horizon": trading_strategy.get("timeframe", "intraday")
    }
    
    entry_signal = trading_strategy.get("entry_signal", "wait")
    current_price = trend_analysis.get("current_price", 0)
    stop_loss = trading_strategy.get("stop_loss_level", 0)
    take_profit_levels = trading_strategy.get("take_profit_levels", [])
    
    # 确定行动建议
    if entry_signal == "buy":
        recommendation["action"] = "buy"
        recommendation["recommendation"] = "买入"
        
        # 添加理由
        if technical_signals.get("moving_average_signals"):
            recommendation["reasoning"].extend(technical_signals["moving_average_signals"][:2])
        
        if trend_analysis.get("trend_direction") == "uptrend":
            recommendation["reasoning"].append("处于上升趋势中")
        
        # 风险水平
        if stop_loss > 0:
            risk_percent = ((current_price - stop_loss) / current_price) * 100
            if risk_percent < 2:
                recommendation["risk_level"] = "low"
            elif risk_percent < 5:
                recommendation["risk_level"] = "medium"
            else:
                recommendation["risk_level"] = "high"
    
    elif entry_signal == "sell":
        recommendation["action"] = "sell"
        recommendation["recommendation"] = "卖出"
        
        # 添加理由
        if technical_signals.get("moving_average_signals"):
            recommendation["reasoning"].extend(technical_signals["moving_average_signals"][:2])
        
        if trend_analysis.get("trend_direction") == "downtrend":
            recommendation["reasoning"].append("处于下降趋势中")
        
        # 风险水平
        if stop_loss > 0:
            risk_percent = ((stop_loss - current_price) / current_price) * 100
            if risk_percent < 2:
                recommendation["risk_level"] = "low"
            elif risk_percent < 5:
                recommendation["risk_level"] = "medium"
            else:
                recommendation["risk_level"] = "high"
    
    else:
        recommendation["reasoning"].append("技术信号不明确，建议观望")
        
        # 检查是否有明确的观望理由
        if trend_analysis.get("trend_direction") == "sideways":
            recommendation["reasoning"].append("市场处于震荡区间")
        
        if technical_signals.get("overall_signal") == "neutral":
            recommendation["reasoning"].append("多空力量均衡")
    
    # 添加具体操作建议
    if recommendation["action"] in ["buy", "sell"]:
        action_details = []
        
        if stop_loss > 0:
            if recommendation["action"] == "buy":
                action_details.append(f"止损位: ${stop_loss:.2f}")
            else:
                action_details.append(f"止损位: ${stop_loss:.2f}")
        
        if take_profit_levels:
            for i, level in enumerate(take_profit_levels[:2], 1):
                action_details.append(f"止盈位{i}: ${level:.2f}")
        
        if action_details:
            recommendation["reasoning"].append("操作建议: " + ", ".join(action_details))
    
    # 根据信心度调整建议强度
    confidence = recommendation["confidence"]
    if confidence > 0.8:
        recommendation["recommendation"] = "强烈" + recommendation["recommendation"]
    elif confidence < 0.4:
        recommendation["recommendation"] = "谨慎" + recommendation["recommendation"]
    
    return recommendation
```

## 数据源
1. **价格数据**: 开盘价、最高价、最低价、收盘价
2. **成交量数据**: 交易量
3. **技术指标**: 移动平均线、RSI、MACD等
4. **市场数据**: 波动率、流动性指标

## 分析流程
1. 加载价格和成交量数据
2. 