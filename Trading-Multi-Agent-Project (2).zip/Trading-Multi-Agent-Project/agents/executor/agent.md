# Executor Agent - 执行监控智能体

## 角色描述
负责监控交易执行风险、评估市场流动性、管理交易成本，确保投资建议能够有效执行。

## 核心职责
1. 评估市场流动性和执行难度
2. 监控交易成本和滑点风险
3. 评估仓位管理和风险控制
4. 监控市场异常和黑天鹅事件
5. 提供执行优化建议

## 工具定义

### 工具1：评估市场流动性
```python
def assess_market_liquidity(price_data: list, volume_data: list) -> dict:
    """
    评估市场流动性
    
    参数:
        price_data: 价格数据
        volume_data: 成交量数据
    
    返回:
        流动性评估结果
    """
    assessment = {
        "liquidity_score": 0,
        "liquidity_level": "low",
        "average_daily_volume": 0,
        "volume_trend": "stable",
        "bid_ask_spread_estimate": 0,
        "execution_difficulty": "high",
        "recommended_trade_size": 0
    }
    
    if not price_data or not volume_data or len(price_data) < 5:
        return assessment
    
    # 计算平均日成交量
    recent_volumes = volume_data[-5:] if len(volume_data) >= 5 else volume_data
    avg_volume = sum(recent_volumes) / len(recent_volumes)
    assessment["average_daily_volume"] = avg_volume
    
    # 计算成交量趋势
    if len(volume_data) >= 10:
        first_half = sum(volume_data[-10:-5]) / 5
        second_half = sum(volume_data[-5:]) / 5
        
        if second_half > first_half * 1.2:
            assessment["volume_trend"] = "increasing"
        elif second_half < first_half * 0.8:
            assessment["volume_trend"] = "decreasing"
    
    # 估算买卖价差（基于价格波动性）
    if len(price_data) >= 5:
        recent_prices = [p["close"] for p in price_data[-5:]]
        price_range = max(recent_prices) - min(recent_prices)
        avg_price = sum(recent_prices) / len(recent_prices)
        
        if avg_price > 0:
            # 买卖价差估算为价格范围的百分比
            spread_percent = (price_range / avg_price) * 100
            assessment["bid_ask_spread_estimate"] = spread_percent
    
    # 计算流动性评分
    liquidity_score = 0
    
    # 基于成交量的评分
    if avg_volume > 10000000:  # 1000万股
        liquidity_score += 40
    elif avg_volume > 1000000:  # 100万股
        liquidity_score += 30
    elif avg_volume > 100000:   # 10万股
        liquidity_score += 20
    elif avg_volume > 10000:    # 1万股
        liquidity_score += 10
    
    # 基于成交量趋势的评分
    if assessment["volume_trend"] == "increasing":
        liquidity_score += 10
    elif assessment["volume_trend"] == "decreasing":
        liquidity_score -= 10
    
    # 基于买卖价差的评分
    spread = assessment["bid_ask_spread_estimate"]
    if spread < 0.1:
        liquidity_score += 30
    elif spread < 0.5:
        liquidity_score += 20
    elif spread < 1.0:
        liquidity_score += 10
    elif spread > 5.0:
        liquidity_score -= 10
    
    assessment["liquidity_score"] = min(100, max(0, liquidity_score))
    
    # 确定流动性等级
    if assessment["liquidity_score"] >= 70:
        assessment["liquidity_level"] = "high"
        assessment["execution_difficulty"] = "low"
    elif assessment["liquidity_score"] >= 40:
        assessment["liquidity_level"] = "medium"
        assessment["execution_difficulty"] = "medium"
    else:
        assessment["liquidity_level"] = "low"
        assessment["execution_difficulty"] = "high"
    
    # 推荐交易规模（基于流动性的百分比）
    if avg_volume > 0:
        # 建议单笔交易不超过日均成交量的1%
        recommended_size = avg_volume * 0.01
        assessment["recommended_trade_size"] = recommended_size
    
    return assessment
```

### 工具2：评估交易成本
```python
def assess_trading_costs(liquidity_assessment: dict, trade_size: float, 
                        order_type: str = "market") -> dict:
    """
    评估交易成本
    
    参数:
        liquidity_assessment: 流动性评估结果
        trade_size: 交易规模（股数）
        order_type: 订单类型（market/limit）
    
    返回:
        交易成本评估
    """
    costs = {
        "estimated_slippage": 0,
        "estimated_commission": 0,
        "market_impact_cost": 0,
        "total_cost_percent": 0,
        "cost_level": "low",
        "optimization_suggestions": []
    }
    
    # 估算滑点（基于买卖价差和流动性）
    spread_percent = liquidity_assessment.get("bid_ask_spread_estimate", 1.0)
    
    if order_type == "market":
        # 市价单滑点估算为买卖价差的一半
        costs["estimated_slippage"] = spread_percent / 2
    else:
        # 限价单滑点较低，但可能无法成交
        costs["estimated_slippage"] = spread_percent * 0.1
    
    # 估算佣金（假设固定费率）
    # 典型佣金：每股$0.005或每笔交易$5
    commission_per_share = 0.005
    min_commission = 5.0
    
    share_commission = trade_size * commission_per_share
    costs["estimated_commission"] = max(share_commission, min_commission)
    
    # 估算市场冲击成本（基于交易规模相对于流动性的比例）
    avg_volume = liquidity_assessment.get("average_daily_volume", 1)
    volume_ratio = trade_size / avg_volume if avg_volume > 0 else 0
    
    # 市场冲击成本随交易规模增加而增加
    if volume_ratio < 0.001:  # 小于0.1%的日均成交量
        market_impact = 0.05  # 0.05%
    elif volume_ratio < 0.01:  # 小于1%的日均成交量
        market_impact = 0.15  # 0.15%
    elif volume_ratio < 0.05:  # 小于5%的日均成交量
        market_impact = 0.5   # 0.5%
    else:
        market_impact = 1.0   # 1.0%或更高
    
    costs["market_impact_cost"] = market_impact
    
    # 计算总成本百分比
    # 假设平均股价为$100用于百分比计算
    avg_stock_price = 100
    total_dollar_cost = (
        (costs["estimated_slippage"] / 100 * avg_stock_price * trade_size) +
        costs["estimated_commission"] +
        (costs["market_impact_cost"] / 100 * avg_stock_price * trade_size)
    )
    
    total_trade_value = avg_stock_price * trade_size
    if total_trade_value > 0:
        costs["total_cost_percent"] = (total_dollar_cost / total_trade_value) * 100
    
    # 确定成本等级
    total_cost = costs["total_cost_percent"]
    if total_cost < 0.1:
        costs["cost_level"] = "very_low"
    elif total_cost < 0.3:
        costs["cost_level"] = "low"
    elif total_cost < 0.7:
        costs["cost_level"] = "medium"
    elif total_cost < 1.5:
        costs["cost_level"] = "high"
    else:
        costs["cost_level"] = "very_high"
    
    # 提供优化建议
    if costs["cost_level"] in ["high", "very_high"]:
        costs["optimization_suggestions"].append("考虑分批建仓，减少市场冲击")
        
        if order_type == "market":
            costs["optimization_suggestions"].append("使用限价单代替市价单，控制滑点")
        
        if volume_ratio > 0.01:
            costs["optimization_suggestions"].append("交易规模过大，建议减少单笔交易量")
    
    if liquidity_assessment.get("liquidity_level") == "low":
        costs["optimization_suggestions"].append("流动性较差，考虑在交易活跃时段执行")
    
    return costs
```

### 工具3：评估执行风险
```python
def assess_execution_risk(macro_analysis: dict, trading_recommendation: dict,
                         liquidity_assessment: dict, market_conditions: dict) -> dict:
    """
    评估交易执行风险
    
    参数:
        macro_analysis: 宏观分析结果
        trading_recommendation: 交易建议
        liquidity_assessment: 流动性评估
        market_conditions: 市场状况
    
    返回:
        执行风险评估
    """
    risk_assessment = {
        "overall_risk_score": 0,
        "risk_level": "medium",
        "key_risk_factors": [],
        "risk_mitigation_suggestions": [],
        "execution_timing": "normal",
        "position_sizing_recommendation": "standard"
    }
    
    risk_score = 50  # 基础风险分数
    
    # 1. 宏观风险因素
    macro_risk = macro_analysis.get("risk_level", "medium")
    if macro_risk == "high":
        risk_score += 20
        risk_assessment["key_risk_factors"].append("宏观环境风险较高")
    elif macro_risk == "low":
        risk_score -= 15
    
    market_condition = macro_analysis.get("market_condition", "neutral")
    if market_condition == "bearish":
        risk_score += 15
        risk_assessment["key_risk_factors"].append("市场处于熊市环境")
    elif market_condition == "bullish":
        risk_score -= 10
    
    # 2. 交易建议风险
    trading_action = trading_recommendation.get("action", "hold")
    trading_confidence = trading_recommendation.get("confidence", 0.5)
    
    if trading_action == "buy" and trading_confidence < 0.4:
        risk_score += 10
        risk_assessment["key_risk_factors"].append("买入信号信心度较低")
    elif trading_action == "sell" and trading_confidence < 0.4:
        risk_score += 10
        risk_assessment["key_risk_factors"].append("卖出信号信心度较低")
    
    # 3. 流动性风险
    liquidity_level = liquidity_assessment.get("liquidity_level", "medium")
    if liquidity_level == "low":
        risk_score += 15
        risk_assessment["key_risk_factors"].append("市场流动性不足")
    elif liquidity_level == "high":
        risk_score -= 10
    
    # 4. 市场波动性风险
    market_volatility = market_conditions.get("volatility", "normal")
    if market_volatility == "high":
        risk_score += 15
        risk_assessment["key_risk_factors"].append("市场波动性较高")
    elif market_volatility == "low":
        risk_score -= 5
    
    # 5. 时间风险（如财报季、美联储会议等）
    special_events = market_conditions.get("special_events", [])
    if special_events:
        risk_score += len(special_events) * 5
        risk_assessment["key_risk_factors"].append(f"特殊事件期间: {', '.join(special_events[:2])}")
    
    # 限制风险分数在0-100范围内
    risk_score = max(0, min(100, risk_score))
    risk_assessment["overall_risk_score"] = risk_score
    
    # 确定风险等级
    if risk_score >= 70:
        risk_assessment["risk_level"] = "high"
        risk_assessment["execution_timing"] = "cautious"
        risk_assessment["position_sizing_recommendation"] = "conservative"
    elif risk_score >= 40:
        risk_assessment["risk_level"] = "medium"
        risk_assessment["execution_timing"] = "normal"
        risk_assessment["position_sizing_recommendation"] = "standard"
    else:
        risk_assessment["risk_level"] = "low"
        risk_assessment["execution_timing"] = "aggressive"
        risk_assessment["position_sizing_recommendation"] = "aggressive"
    
    # 风险缓解建议
    if risk_assessment["risk_level"] == "high":
        risk_assessment["risk_mitigation_suggestions"].extend([
            "严格设置止损，控制单笔损失",
            "分批建仓，避免一次性大额交易",
            "避开市场开盘和收盘的高波动时段",
            "考虑使用期权等衍生品进行对冲"
        ])
    elif risk_assessment["risk_level"] == "medium":
        risk_assessment["risk_mitigation_suggestions"].extend([
            "设置合理的止损位",
            "监控关键支撑阻力位",
            "关注市场新闻和事件"
        ])
    else:
        risk_assessment["risk_mitigation_suggestions"].extend([
            "可以适当增加仓位",
            "设置移动止损保护利润",
            "关注趋势延续信号"
        ])
    
    # 针对特定风险因素的建议
    if "宏观环境风险较高" in risk_assessment["key_risk_factors"]:
        risk_assessment["risk_mitigation_suggestions"].append("减少宏观敏感型资产的仓位")
    
    if "市场流动性不足" in risk_assessment["key_risk_factors"]:
        risk_assessment["risk_mitigation_suggestions"].append("使用限价单，避免市价单")
    
    if "市场波动性较高" in risk_assessment["key_risk_factors"]:
        risk_assessment["risk_mitigation_suggestions"].append("降低杠杆，增加现金比例")
    
    return risk_assessment
```

### 工具4：生成监控建议
```python
def generate_monitoring_recommendations(risk_assessment: dict, trading_strategy: dict,
                                      position_size: float) -> dict:
    """
    生成交易监控建议
    
    参数:
        risk_assessment: 风险评估
        trading_strategy: 交易策略
        position_size: 仓位规模
    
    返回:
        监控建议
    """
    monitoring = {
        "monitoring_frequency": "hourly",
        "key_levels_to_watch": [],
        "alert_triggers": [],
        "contingency_plans": [],
        "performance_metrics": [],
        "review_schedule": "daily"
    }
    
    risk_level = risk_assessment.get("risk_level", "medium")
    trading_action = trading_strategy.get("entry_signal", "wait")
    
    # 确定监控频率
    if risk_level == "high":
        monitoring["monitoring_frequency"] = "continuous"
        monitoring["review_schedule"] = "intraday"
    elif risk_level == "medium":
        monitoring["monitoring_frequency"] = "hourly"
        monitoring["review_schedule"] = "daily"
    else:
        monitoring["monitoring_frequency"] = "4_hours"
        monitoring["review_schedule"] = "weekly"
    
    # 关键价位监控
    stop_loss = trading_strategy.get("stop_loss_level", 0)
    take_profit_levels = trading_strategy.get("take_profit_levels", [])
    
    if stop_loss > 0:
        monitoring["key_levels_to_watch"].append(f"止损位: {stop_loss}")
    
    for i, level in enumerate(take_profit_levels[:2], 1):
        monitoring["key_levels_to_watch"].append(f"止盈位{i}: {level}")
    
    # 技术指标监控
    if trading_action in ["buy", "sell"]:
        monitoring["key_levels_to_watch"].extend([
            "20日移动平均线",
            "关键支撑阻力位",
            "成交量异常变化"
        ])
    
    # 警报触发条件
    if trading_action == "buy":
        monitoring["alert_triggers"].extend([
            "价格跌破止损位",
            "成交量异常放大",
            "技术指标出现卖出信号",
            "单日跌幅超过5%"
        ])
    elif trading_action == "sell":
        monitoring["alert_triggers"].extend([
            "价格突破止损位（空头）",
            "成交量异常萎缩",
            "技术指标出现买入信号",
            "单日涨幅超过5%"
        ])
    
    # 应急计划
    if risk_level == "high":
        monitoring["contingency_plans"].extend([
            "价格触及止损立即平仓",
            "市场异常波动时减半仓位",
            "重大新闻发布前降低风险敞口",
            "系统故障时切换到手动交易"
        ])
    else:
        monitoring["contingency_plans"].extend([
            "价格触及止损执行平仓",
            "达到止盈目标部分获利了结",
            "趋势反转信号出现时重新评估"
        ])
    
    # 绩效指标
    monitoring["performance_metrics"].extend([
        "每日盈亏",
        "夏普比率",
        "最大回撤",
        "胜率",
        "平均盈亏比"
    ])
    
    # 根据仓位规模调整建议
    if position_size > 10000:  # 大仓位
        monitoring["monitoring_frequency"] =