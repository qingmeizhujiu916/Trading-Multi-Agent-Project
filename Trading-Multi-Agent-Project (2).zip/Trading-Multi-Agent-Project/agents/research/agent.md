# Research Agent - 个股研究智能体

## 角色描述
负责深度分析公司基本面，包括财务数据、业务模式、竞争优势和估值水平，为投资决策提供基本面支持。

## 核心职责
1. 分析公司财务报表（利润表、资产负债表、现金流量表）
2. 计算关键财务比率和估值指标
3. 评估公司盈利能力和成长性
4. 分析公司竞争优势和行业地位
5. 评估公司治理和风险因素

## 工具定义

### 工具1：分析财务报表
```python
def analyze_financial_statements(financials: dict) -> dict:
    """
    分析公司财务报表
    
    参数:
        financials: 财务数据字典
    
    返回:
        财务分析结果
    """
    analysis = {
        "profitability_analysis": {},
        "liquidity_analysis": {},
        "solvency_analysis": {},
        "efficiency_analysis": {},
        "growth_analysis": {},
        "overall_assessment": ""
    }
    
    if not financials:
        return analysis
    
    # 盈利能力分析
    revenue = financials.get("revenue", 0)
    net_income = financials.get("net_income", 0)
    gross_profit = financials.get("gross_profit", 0)
    
    if revenue > 0:
        analysis["profitability_analysis"]["net_margin"] = (net_income / revenue) * 100
        analysis["profitability_analysis"]["gross_margin"] = (gross_profit / revenue) * 100
    else:
        analysis["profitability_analysis"]["net_margin"] = 0
        analysis["profitability_analysis"]["gross_margin"] = 0
    
    # 流动性分析
    current_assets = financials.get("current_assets", 0)
    current_liabilities = financials.get("current_liabilities", 0)
    inventory = financials.get("inventory", 0)
    
    if current_liabilities > 0:
        analysis["liquidity_analysis"]["current_ratio"] = current_assets / current_liabilities
        analysis["liquidity_analysis"]["quick_ratio"] = (current_assets - inventory) / current_liabilities
    else:
        analysis["liquidity_analysis"]["current_ratio"] = 0
        analysis["liquidity_analysis"]["quick_ratio"] = 0
    
    # 偿债能力分析
    total_assets = financials.get("total_assets", 1)
    total_liabilities = financials.get("total_liabilities", 0)
    equity = financials.get("equity", 1)
    
    analysis["solvency_analysis"]["debt_to_assets"] = (total_liabilities / total_assets) * 100
    analysis["solvency_analysis"]["debt_to_equity"] = (total_liabilities / equity) * 100 if equity > 0 else 0
    
    # 运营效率分析
    analysis["efficiency_analysis"]["asset_turnover"] = revenue / total_assets if total_assets > 0 else 0
    
    # 成长性分析（需要历史数据，这里简化处理）
    analysis["growth_analysis"]["revenue_growth"] = "需要历史数据"
    analysis["growth_analysis"]["earnings_growth"] = "需要历史数据"
    
    # 总体评估
    assessment_score = 0
    total_factors = 0
    
    # 盈利能力评估
    net_margin = analysis["profitability_analysis"].get("net_margin", 0)
    if net_margin > 15:
        assessment_score += 2
    elif net_margin > 8:
        assessment_score += 1
    total_factors += 1
    
    # 流动性评估
    current_ratio = analysis["liquidity_analysis"].get("current_ratio", 0)
    if 1.5 <= current_ratio <= 3:
        assessment_score += 2
    elif 1 <= current_ratio < 1.5 or 3 < current_ratio <= 4:
        assessment_score += 1
    total_factors += 1
    
    # 偿债能力评估
    debt_to_equity = analysis["solvency_analysis"].get("debt_to_equity", 0)
    if debt_to_equity < 50:
        assessment_score += 2
    elif debt_to_equity < 100:
        assessment_score += 1
    total_factors += 1
    
    # 总体评分
    if total_factors > 0:
        score_percentage = (assessment_score / (total_factors * 2)) * 100
        if score_percentage >= 80:
            analysis["overall_assessment"] = "财务状况优秀"
        elif score_percentage >= 60:
            analysis["overall_assessment"] = "财务状况良好"
        elif score_percentage >= 40:
            analysis["overall_assessment"] = "财务状况一般"
        else:
            analysis["overall_assessment"] = "财务状况较差"
    
    return analysis
```

### 工具2：计算估值指标
```python
def calculate_valuation_metrics(financials: dict, market_data: dict) -> dict:
    """
    计算公司估值指标
    
    参数:
        financials: 财务数据
        market_data: 市场数据（包含市值等）
    
    返回:
        估值分析结果
    """
    valuation = {
        "pe_ratio": 0,
        "pb_ratio": 0,
        "ps_ratio": 0,
        "ev_ebitda": 0,
        "dividend_yield": 0,
        "valuation_assessment": ""
    }
    
    if not financials or not market_data:
        return valuation
    
    # 提取数据
    net_income = financials.get("net_income", 0)
    revenue = financials.get("revenue", 0)
    equity = financials.get("equity", 1)
    market_cap = market_data.get("market_cap", 0)
    dividend_yield = market_data.get("dividend_yield", 0)
    
    # 计算PE比率
    if net_income > 0:
        valuation["pe_ratio"] = market_cap / net_income
    else:
        valuation["pe_ratio"] = 0
    
    # 计算PB比率
    if equity > 0:
        valuation["pb_ratio"] = market_cap / equity
    else:
        valuation["pb_ratio"] = 0
    
    # 计算PS比率
    if revenue > 0:
        valuation["ps_ratio"] = market_cap / revenue
    else:
        valuation["ps_ratio"] = 0
    
    # 股息率
    valuation["dividend_yield"] = dividend_yield
    
    # 估值评估
    pe_ratio = valuation["pe_ratio"]
    pb_ratio = valuation["pb_ratio"]
    
    valuation_factors = []
    
    if 0 < pe_ratio < 15:
        valuation_factors.append("PE估值较低")
    elif 15 <= pe_ratio < 25:
        valuation_factors.append("PE估值合理")
    elif pe_ratio >= 25:
        valuation_factors.append("PE估值较高")
    
    if 0 < pb_ratio < 2:
        valuation_factors.append("PB估值较低")
    elif 2 <= pb_ratio < 4:
        valuation_factors.append("PB估值合理")
    elif pb_ratio >= 4:
        valuation_factors.append("PB估值较高")
    
    if dividend_yield > 3:
        valuation_factors.append("股息率有吸引力")
    elif dividend_yield > 1:
        valuation_factors.append("股息率一般")
    else:
        valuation_factors.append("股息率较低")
    
    # 总体估值判断
    low_valuation_count = sum(1 for factor in valuation_factors if "较低" in factor or "有吸引力" in factor)
    high_valuation_count = sum(1 for factor in valuation_factors if "较高" in factor)
    
    if low_valuation_count >= 2:
        valuation["valuation_assessment"] = "估值偏低，具有投资价值"
    elif high_valuation_count >= 2:
        valuation["valuation_assessment"] = "估值偏高，需谨慎"
    else:
        valuation["valuation_assessment"] = "估值合理"
    
    return valuation
```

### 工具3：评估竞争优势
```python
def assess_competitive_advantage(company_data: dict, industry_data: dict) -> dict:
    """
    评估公司竞争优势
    
    参数:
        company_data: 公司数据
        industry_data: 行业数据
    
    返回:
        竞争优势分析
    """
    advantage = {
        "moat_type": [],
        "competitive_strengths": [],
        "weaknesses": [],
        "industry_position": "",
        "sustainable_advantage_score": 0
    }
    
    if not company_data:
        return advantage
    
    # 提取公司信息
    company_name = company_data.get("name", "")
    sector = company_data.get("sector", "")
    industry = company_data.get("industry", "")
    financials = company_data.get("financials", {})
    
    # 判断护城河类型
    # 1. 品牌护城河
    strong_brands = ["Apple", "Microsoft", "Google", "Amazon", "Tesla", "Coca-Cola", "Nike"]
    if any(brand.lower() in company_name.lower() for brand in strong_brands):
        advantage["moat_type"].append("品牌护城河")
        advantage["competitive_strengths"].append("强大的品牌认知度和客户忠诚度")
    
    # 2. 成本护城河
    gross_margin = (financials.get("gross_profit", 0) / financials.get("revenue", 1)) * 100 if financials.get("revenue", 0) > 0 else 0
    if gross_margin > 40:
        advantage["moat_type"].append("成本护城河")
        advantage["competitive_strengths"].append("高毛利率显示成本优势")
    
    # 3. 网络效应护城河
    network_effect_industries = ["Internet", "Software", "Social Media", "E-commerce"]
    if any(industry.lower() in industry.lower() for industry in network_effect_industries):
        advantage["moat_type"].append("网络效应护城河")
        advantage["competitive_strengths"].append("用户网络效应增强平台价值")
    
    # 4. 转换成本护城河
    high_switching_cost_industries = ["Enterprise Software", "Banking", "Telecom"]
    if any(industry.lower() in industry.lower() for industry in high_switching_cost_industries):
        advantage["moat_type"].append("转换成本护城河")
        advantage["competitive_strengths"].append("高转换成本锁定客户")
    
    # 行业地位评估
    market_cap = company_data.get("key_metrics", {}).get("market_cap", 0)
    
    if market_cap > 200000000000:  # 2000亿美元
        advantage["industry_position"] = "行业领导者"
    elif market_cap > 50000000000:  # 500亿美元
        advantage["industry_position"] = "主要参与者"
    elif market_cap > 10000000000:  # 100亿美元
        advantage["industry_position"] = "中型公司"
    else:
        advantage["industry_position"] = "小型公司"
    
    # 可持续竞争优势评分
    score = 0
    
    # 护城河数量
    score += len(advantage["moat_type"]) * 20
    
    # 行业地位
    if advantage["industry_position"] == "行业领导者":
        score += 30
    elif advantage["industry_position"] == "主要参与者":
        score += 20
    elif advantage["industry_position"] == "中型公司":
        score += 10
    
    # 财务健康度（简化）
    roe = (financials.get("net_income", 0) / financials.get("equity", 1)) * 100 if financials.get("equity", 0) > 0 else 0
    if roe > 15:
        score += 25
    elif roe > 8:
        score += 15
    elif roe > 0:
        score += 5
    
    advantage["sustainable_advantage_score"] = min(score, 100)
    
    # 识别弱点
    debt_to_equity = (financials.get("total_liabilities", 0) / financials.get("equity", 1)) * 100 if financials.get("equity", 0) > 0 else 0
    if debt_to_equity > 100:
        advantage["weaknesses"].append("负债率较高")
    
    if len(advantage["moat_type"]) == 0:
        advantage["weaknesses"].append("缺乏明显的竞争优势")
    
    return advantage
```

### 工具4：生成投资建议
```python
def generate_investment_recommendation(financial_analysis: dict, valuation: dict, 
                                      competitive_advantage: dict) -> dict:
    """
    生成基本面投资建议
    
    参数:
        financial_analysis: 财务分析结果
        valuation: 估值分析结果
        competitive_advantage: 竞争优势分析
    
    返回:
        投资建议
    """
    recommendation = {
        "recommendation": "持有",
        "confidence_level": "中等",
        "target_price_range": "",
        "time_horizon": "中长期",
        "key_reasons": [],
        "risks": []
    }
    
    # 收集评分因素
    scores = []
    weights = []
    
    # 1. 财务健康度评分
    financial_score = 0
    financial_assessment = financial_analysis.get("overall_assessment", "")
    if "优秀" in financial_assessment:
        financial_score = 90
    elif "良好" in financial_assessment:
        financial_score = 70
    elif "一般" in financial_assessment:
        financial_score = 50
    else:
        financial_score = 30
    scores.append(financial_score)
    weights.append(0.4)
    
    # 2. 估值吸引力评分
    valuation_score = 0
    valuation_assessment = valuation.get("valuation_assessment", "")
    if "偏低" in valuation_assessment:
        valuation_score = 85
    elif "合理" in valuation_assessment:
        valuation_score = 65
    else:
        valuation_score = 40
    scores.append(valuation_score)
    weights.append(0.3)
    
    # 3. 竞争优势评分
    competitive_score = competitive_advantage.get("sustainable_advantage_score", 50)
    scores.append(competitive_score)
    weights.append(0.3)
    
    # 计算加权平均分
    total_weight = sum(weights)
    weighted_score = sum(s * w for s, w in zip(scores, weights)) / total_weight
    
    # 生成建议
    if weighted_score >= 80:
        recommendation["recommendation"] = "强烈买入"
        recommendation["confidence_level"] = "高"
        recommendation["key_reasons"].append("财务健康，估值有吸引力，竞争优势明显")
    elif weighted_score >= 65:
        recommendation["recommendation"] = "买入"
        recommendation["confidence_level"] = "中等"
        recommendation["key_reasons"].append("基本面良好，估值合理")
    elif weighted_score >= 50:
        recommendation["recommendation"] = "持有"
        recommendation["confidence_level"] = "中等"
        recommendation["key_reasons"].append("基本面一般，建议观望")
    elif weighted_score >= 35:
        recommendation["recommendation"] = "减持"
        recommendation["confidence_level"] = "中等"
        recommendation["key_reasons"].append("基本面或估值存在担忧")
    else:
        recommendation["recommendation"] = "卖出"
        recommendation["confidence_level"] = "高"
        recommendation["key_reasons"].append("基本面较差，估值过高")
    
    # 识别风险
    weaknesses = competitive_advantage.get("weaknesses", [])
    if weaknesses:
        recommendation["risks"].extend(weaknesses)
    
    debt_to_equity = financial_analysis.get("solvency_analysis", {}).get("debt_to_equity", 0)
    if debt_to_equity > 100:
        recommendation["risks"].append("高负债风险")
    
    pe_ratio = valuation.get("pe_ratio", 0)
    if pe_ratio > 30:
        recommendation["risks"].append("估值过高风险")
    
    return recommendation
```

## 数据源
1. **财务报表**: 利润表、资产负债表、现金流量表
2. **估值数据**: 市值、市盈率、市净率、股息率
3. **行业数据**: 行业平均估值、竞争格局
4. **公司信息**: 业务模式、竞争优势、管理层

## 分析流程
1. 加载公司财务数据
2. 分析财务报表和关键比率
3. 计算估值指标并评估吸引力
4. 分析公司竞争优势和护城河
5. 评估公司治理和风险因素
6. 生成基本面投资建议

## 输出格式
```json
{
  "financial_analysis": {
    "profitability": {
      "net_margin": 25.3,
      "gross_margin": 44.1
    },
    "liquidity": {
      "current_ratio": 2.1,
      "quick_ratio": 1.8
    },
    "solvency": {
      "debt_to_equity": 45.2
    },
    "overall_assessment": "财务状况优秀"
  },
  "valuation_analysis": {
    "pe_ratio": 28.5,
    "pb_ratio": 38.2,
    "dividend_yield": 0.52,
    "valuation_assessment": "估值合理"
  },
  "competitive_analysis": {
    "moat_type": ["品牌护城河", "网络效应护城河"],
    "industry_position": "行业领导者",
    "sustainable_advantage_score": 85
  },
  "investment_recommend