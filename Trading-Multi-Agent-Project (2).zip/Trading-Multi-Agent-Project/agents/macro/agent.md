# Macro Agent - 宏观分析智能体

## 角色描述
负责分析宏观经济环境、市场整体趋势和行业表现，为投资决策提供宏观背景支持。

## 核心职责
1. 分析整体市场状况（牛市/熊市/震荡市）
2. 评估宏观经济指标（GDP、通胀、利率等）
3. 监控主要指数表现（S&P500、NASDAQ、道琼斯）
4. 分析行业轮动和板块表现
5. 评估市场情绪和风险偏好

## 工具定义

### 工具1：分析市场宏观环境
```python
def analyze_market_environment(market_data: dict) -> dict:
    """
    分析市场宏观环境
    
    参数:
        market_data: 市场数据字典，包含指数、经济指标等信息
    
    返回:
        宏观分析结果，包含市场状况、风险等级和建议
    """
    analysis = {
        "market_condition": "neutral",
        "risk_level": "medium",
        "recommendation": "中性持有",
        "key_indicators": {},
        "sector_analysis": {},
        "market_sentiment": {}
    }
    
    # 分析市场状况
    if "market_overview" in market_data:
        overview = market_data["market_overview"]
        
        # 判断市场状况
        indices = overview.get("major_indices", {})
        positive_changes = 0
        total_indices = 0
        
        for index_name, index_data in indices.items():
            if isinstance(index_data, dict) and "change" in index_data:
                total_indices += 1
                if index_data["change"] > 0:
                    positive_changes += 1
        
        if total_indices > 0:
            positive_ratio = positive_changes / total_indices
            if positive_ratio >= 0.7:
                analysis["market_condition"] = "bullish"
            elif positive_ratio <= 0.3:
                analysis["market_condition"] = "bearish"
            else:
                analysis["market_condition"] = "neutral"
        
        # 提取风险等级
        analysis["risk_level"] = overview.get("risk_level", "medium")
        
        # 提取关键指标
        if "major_indices" in overview:
            analysis["key_indicators"] = {
                "sp500_change": overview["major_indices"].get("sp500", {}).get("change", 0),
                "nasdaq_change": overview["major_indices"].get("nasdaq", {}).get("change", 0),
                "dow_change": overview["major_indices"].get("dow_jones", {}).get("change", 0)
            }
        
        # 分析行业表现
        if "sector_performance" in overview:
            analysis["sector_analysis"] = overview["sector_performance"]
        
        # 分析市场情绪
        if "market_sentiment" in overview:
            analysis["market_sentiment"] = overview["market_sentiment"]
    
    # 生成建议
    analysis["recommendation"] = generate_macro_recommendation(
        analysis["market_condition"],
        analysis["risk_level"]
    )
    
    return analysis

def generate_macro_recommendation(market_condition: str, risk_level: str) -> str:
    """根据市场状况和风险等级生成宏观建议"""
    if market_condition == "bullish" and risk_level == "low":
        return "积极投资"
    elif market_condition == "bullish" and risk_level == "medium":
        return "适度增仓"
    elif market_condition == "bullish" and risk_level == "high":
        return "谨慎乐观"
    elif market_condition == "bearish" and risk_level == "high":
        return "谨慎观望"
    elif market_condition == "bearish" and risk_level == "medium":
        return "减仓防御"
    elif market_condition == "neutral" and risk_level == "low":
        return "中性偏多"
    elif market_condition == "neutral" and risk_level == "high":
        return "中性偏空"
    else:
        return "中性持有"
```

### 工具2：分析经济指标
```python
def analyze_economic_indicators(economic_data: dict) -> dict:
    """
    分析宏观经济指标
    
    参数:
        economic_data: 经济指标数据
    
    返回:
        经济分析结果
    """
    analysis = {
        "gdp_analysis": "",
        "inflation_analysis": "",
        "employment_analysis": "",
        "interest_rate_analysis": "",
        "overall_assessment": ""
    }
    
    if not economic_data:
        return analysis
    
    # GDP分析
    gdp_growth = economic_data.get("gdp_growth", 0)
    if gdp_growth > 3:
        analysis["gdp_analysis"] = "经济强劲增长"
    elif gdp_growth > 2:
        analysis["gdp_analysis"] = "经济温和增长"
    elif gdp_growth > 0:
        analysis["gdp_analysis"] = "经济低速增长"
    else:
        analysis["gdp_analysis"] = "经济收缩"
    
    # 通胀分析
    inflation = economic_data.get("inflation_rate", 0)
    if inflation > 3:
        analysis["inflation_analysis"] = "通胀压力较大"
    elif inflation > 2:
        analysis["inflation_analysis"] = "通胀温和"
    elif inflation > 1:
        analysis["inflation_analysis"] = "通胀偏低"
    else:
        analysis["inflation_analysis"] = "通缩风险"
    
    # 就业分析
    unemployment = economic_data.get("unemployment_rate", 0)
    if unemployment < 4:
        analysis["employment_analysis"] = "就业市场强劲"
    elif unemployment < 6:
        analysis["employment_analysis"] = "就业市场稳定"
    else:
        analysis["employment_analysis"] = "就业市场疲软"
    
    # 利率分析
    interest_rate = economic_data.get("interest_rate", 0)
    if interest_rate > 5:
        analysis["interest_rate_analysis"] = "高利率环境"
    elif interest_rate > 3:
        analysis["interest_rate_analysis"] = "利率适中"
    else:
        analysis["interest_rate_analysis"] = "低利率环境"
    
    # 总体评估
    positive_factors = 0
    total_factors = 4
    
    if gdp_growth > 2:
        positive_factors += 1
    if 1.5 < inflation < 3:
        positive_factors += 1
    if unemployment < 5:
        positive_factors += 1
    if 2 < interest_rate < 4:
        positive_factors += 1
    
    positive_ratio = positive_factors / total_factors
    if positive_ratio >= 0.75:
        analysis["overall_assessment"] = "经济环境良好"
    elif positive_ratio >= 0.5:
        analysis["overall_assessment"] = "经济环境一般"
    else:
        analysis["overall_assessment"] = "经济环境较差"
    
    return analysis
```

### 工具3：分析行业表现
```python
def analyze_sector_performance(sector_data: dict) -> dict:
    """
    分析行业板块表现
    
    参数:
        sector_data: 行业表现数据
    
    返回:
        行业分析结果
    """
    analysis = {
        "outperforming_sectors": [],
        "underperforming_sectors": [],
        "neutral_sectors": [],
        "recommended_sectors": [],
        "sector_rotation_analysis": ""
    }
    
    if not sector_data:
        return analysis
    
    # 分类行业表现
    for sector, performance in sector_data.items():
        if performance == "outperforming":
            analysis["outperforming_sectors"].append(sector)
        elif performance == "underperforming":
            analysis["underperforming_sectors"].append(sector)
        else:
            analysis["neutral_sectors"].append(sector)
    
    # 推荐行业（表现优异且具有持续性）
    recommended_sectors = []
    for sector in analysis["outperforming_sectors"]:
        # 这里可以添加更复杂的逻辑来判断行业的持续性
        if sector in ["technology", "healthcare", "consumer_discretionary"]:
            recommended_sectors.append(sector)
    
    analysis["recommended_sectors"] = recommended_sectors
    
    # 行业轮动分析
    if len(analysis["outperforming_sectors"]) > len(analysis["underperforming_sectors"]):
        analysis["sector_rotation_analysis"] = "市场风险偏好较高，成长板块表现突出"
    elif len(analysis["underperforming_sectors"]) > len(analysis["outperforming_sectors"]):
        analysis["sector_rotation_analysis"] = "市场风险偏好较低，防御板块相对稳健"
    else:
        analysis["sector_rotation_analysis"] = "市场板块轮动均衡"
    
    return analysis
```

### 工具4：分析市场情绪
```python
def analyze_market_sentiment(sentiment_data: dict) -> dict:
    """
    分析市场情绪指标
    
    参数:
        sentiment_data: 市场情绪数据
    
    返回:
        情绪分析结果
    """
    analysis = {
        "fear_greed_index": 50,
        "vix_analysis": "",
        "put_call_analysis": "",
        "overall_sentiment": "neutral"
    }
    
    if not sentiment_data:
        return analysis
    
    # 恐惧贪婪指数
    fear_greed = sentiment_data.get("fear_greed_index", 50)
    analysis["fear_greed_index"] = fear_greed
    
    # VIX指数分析
    vix = sentiment_data.get("vix_index", 20)
    if vix < 15:
        analysis["vix_analysis"] = "市场恐慌情绪较低，投资者情绪乐观"
    elif vix < 25:
        analysis["vix_analysis"] = "市场情绪正常"
    else:
        analysis["vix_analysis"] = "市场恐慌情绪较高，投资者情绪谨慎"
    
    # 看跌看涨比率分析
    put_call = sentiment_data.get("put_call_ratio", 0.7)
    if put_call > 1:
        analysis["put_call_analysis"] = "看跌情绪占主导"
    elif put_call > 0.8:
        analysis["put_call_analysis"] = "略偏看跌"
    elif put_call > 0.6:
        analysis["put_call_analysis"] = "情绪均衡"
    else:
        analysis["put_call_analysis"] = "看涨情绪占主导"
    
    # 总体情绪判断
    sentiment_score = 0
    if fear_greed > 60:
        sentiment_score += 1
    elif fear_greed < 40:
        sentiment_score -= 1
    
    if vix < 20:
        sentiment_score += 1
    elif vix > 30:
        sentiment_score -= 1
    
    if put_call < 0.7:
        sentiment_score += 1
    elif put_call > 1:
        sentiment_score -= 1
    
    if sentiment_score >= 2:
        analysis["overall_sentiment"] = "bullish"
    elif sentiment_score <= -2:
        analysis["overall_sentiment"] = "bearish"
    else:
        analysis["overall_sentiment"] = "neutral"
    
    return analysis
```

## 数据源
1. **市场数据**: S&P500、NASDAQ、道琼斯等主要指数
2. **经济指标**: GDP增长率、通胀率、失业率、利率
3. **行业数据**: 各行业板块表现数据
4. **情绪指标**: 恐惧贪婪指数、VIX指数、看跌看涨比率

## 分析流程
1. 加载市场宏观数据
2. 分析市场整体状况和趋势
3. 评估经济指标健康度
4. 分析行业轮动和板块表现
5. 评估市场情绪和风险偏好
6. 生成宏观投资建议

## 输出格式
```json
{
  "market_condition": "bullish",
  "risk_level": "medium",
  "recommendation": "适度增仓",
  "key_indicators": {
    "sp500_change": 15.32,
    "nasdaq_change": 45.21,
    "dow_change": 120.45
  },
  "economic_analysis": {
    "gdp_analysis": "经济温和增长",
    "overall_assessment": "经济环境良好"
  },
  "sector_analysis": {
    "outperforming_sectors": ["technology", "energy"],
    "recommended_sectors": ["technology"]
  },
  "sentiment_analysis": {
    "overall_sentiment": "bullish",
    "fear_greed_index": 65
  }
}
```

## 配置参数
```yaml
macro_agent:
  data_refresh_interval: 3600  # 数据刷新间隔（秒）
  analysis_depth: "standard"   # 分析深度（basic/standard/advanced）
  include_sector_analysis: true
  include_sentiment_analysis: true
  confidence_threshold: 0.7    # 信心度阈值