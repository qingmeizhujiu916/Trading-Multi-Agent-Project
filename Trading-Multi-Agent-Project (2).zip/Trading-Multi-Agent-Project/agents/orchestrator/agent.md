# Orchestrator Agent - 总指挥智能体

## 角色描述
作为多智能体系统的总指挥，负责接收用户请求，协调各个智能体的工作流程，整合分析结果，并生成最终的投资建议报告。

## 核心职责
1. 接收用户查询（如："分析AAPL的投资价值"）
2. 根据查询类型决定调用哪些智能体
3. 协调智能体间的数据传递和时序
4. 整合各智能体的分析结果
5. 生成结构化的最终报告

## 工具定义

### 工具1：协调分析工作流
```python
def coordinate_analysis_workflow(user_query: str, analysis_type: str = "full") -> dict:
    """
    根据用户查询协调分析工作流
    
    参数:
        user_query: 用户查询字符串
        analysis_type: 分析类型 ("full" | "quick" | "macro_only")
    
    返回:
        协调结果字典，包含调用的智能体和执行顺序
    """
    # 解析用户查询，提取公司代码
    ticker = extract_ticker_from_query(user_query)
    
    workflow = {
        "ticker": ticker,
        "analysis_type": analysis_type,
        "workflow_steps": [],
        "estimated_time": 0
    }
    
    if analysis_type == "full":
        workflow["workflow_steps"] = ["macro", "research", "trading", "executor"]
        workflow["estimated_time"] = 120  # 秒
    elif analysis_type == "quick":
        workflow["workflow_steps"] = ["research", "trading"]
        workflow["estimated_time"] = 60  # 秒
    elif analysis_type == "macro_only":
        workflow["workflow_steps"] = ["macro"]
        workflow["estimated_time"] = 30  # 秒
    
    return workflow

def extract_ticker_from_query(query: str) -> str:
    """从查询中提取公司代码"""
    import re
    
    # 常见公司代码模式
    ticker_patterns = [
        r'\b(AAPL|TSLA|BABA|GOOGL|MSFT|AMZN|META|NVDA)\b',
        r'\b([A-Z]{2,5})\b'
    ]
    
    for pattern in ticker_patterns:
        match = re.search(pattern, query.upper())
        if match:
            return match.group(1)
    
    return "UNKNOWN"
```

### 工具2：整合分析结果
```python
def integrate_analysis_results(macro_result: dict, research_result: dict, 
                              trading_result: dict, executor_result: dict) -> dict:
    """
    整合所有智能体的分析结果
    
    参数:
        macro_result: 宏观分析结果
        research_result: 个股研究结果
        trading_result: 交易策略结果
        executor_result: 执行监控结果
    
    返回:
        整合后的完整分析报告
    """
    integrated_report = {
        "summary": generate_summary(macro_result, research_result, trading_result, executor_result),
        "detailed_analysis": {
            "macro_analysis": macro_result,
            "research_analysis": research_result,
            "trading_analysis": trading_result,
            "executor_analysis": executor_result
        },
        "recommendations": generate_recommendations(macro_result, research_result, trading_result, executor_result),
        "risk_assessment": extract_risk_assessment(executor_result),
        "confidence_score": calculate_confidence_score(macro_result, research_result, trading_result)
    }
    
    return integrated_report

def generate_summary(macro: dict, research: dict, trading: dict, executor: dict) -> str:
    """生成分析摘要"""
    parts = []
    
    if macro and "recommendation" in macro:
        parts.append(f"宏观: {macro['recommendation']}")
    
    if research and "recommendation" in research:
        parts.append(f"基本面: {research['recommendation']}")
    
    if trading and "trading_recommendation" in trading:
        parts.append(f"技术面: {trading['trading_recommendation']}")
    
    if executor and "risk_assessment" in executor:
        risk_level = executor["risk_assessment"].get("risk_level", "未知")
        parts.append(f"风险: {risk_level}")
    
    return " | ".join(parts) if parts else "分析完成"

def generate_recommendations(macro: dict, research: dict, trading: dict, executor: dict) -> list:
    """生成详细建议"""
    recommendations = []
    
    # 宏观建议
    if macro and "recommendation" in macro:
        recommendations.append({
            "type": "宏观策略",
            "content": macro["recommendation"],
            "priority": "high"
        })
    
    # 基本面建议
    if research and "recommendation" in research:
        recommendations.append({
            "type": "投资建议",
            "content": research["recommendation"],
            "priority": "high"
        })
    
    # 技术面建议
    if trading and "trading_recommendation" in trading:
        recommendations.append({
            "type": "交易策略",
            "content": trading["trading_recommendation"],
            "confidence": trading.get("confidence", 0.5),
            "priority": "medium"
        })
    
    # 风险控制建议
    if executor and "risk_assessment" in executor:
        risk_recs = executor["risk_assessment"].get("recommendations", [])
        for rec in risk_recs[:3]:  # 取前3个建议
            recommendations.append({
                "type": "风险控制",
                "content": rec,
                "priority": "medium"
            })
    
    return recommendations

def extract_risk_assessment(executor_result: dict) -> dict:
    """提取风险评估"""
    if not executor_result or "risk_assessment" not in executor_result:
        return {
            "overall_risk": 0.5,
            "risk_level": "中等风险",
            "monitoring_points": ["市场波动性", "流动性风险"]
        }
    
    return executor_result["risk_assessment"]

def calculate_confidence_score(macro: dict, research: dict, trading: dict) -> float:
    """计算信心度评分"""
    scores = []
    weights = []
    
    # 宏观信心度
    if macro and "key_indicators" in macro:
        scores.append(0.7)  # 宏观分析通常有较高信心度
        weights.append(0.2)
    
    # 基本面信心度
    if research and "fundamental_score" in research:
        fund_score = research["fundamental_score"]
        scores.append(fund_score / 100)  # 转换为0-1范围
        weights.append(0.4)
    
    # 技术面信心度
    if trading and "confidence" in trading:
        scores.append(trading["confidence"])
        weights.append(0.3)
    
    # 风险信心度
    if "executor" in locals() and executor and "risk_assessment" in executor:
        risk_score = executor["risk_assessment"].get("overall_risk", 0.5)
        scores.append(1 - risk_score)  # 风险越低信心越高
        weights.append(0.1)
    
    if not scores:
        return 0.5
    
    # 加权平均
    total_weight = sum(weights)
    weighted_sum = sum(s * w for s, w in zip(scores, weights))
    return weighted_sum / total_weight
```

### 工具3：生成最终报告
```python
def generate_final_report(integrated_data: dict, format: str = "markdown") -> str:
    """
    生成最终投资建议报告
    
    参数:
        integrated_data: 整合后的数据
        format: 报告格式 ("markdown" | "json" | "html")
    
    返回:
        格式化的报告字符串
    """
    if format == "markdown":
        return generate_markdown_report(integrated_data)
    elif format == "json":
        import json
        return json.dumps(integrated_data, indent=2, ensure_ascii=False)
    elif format == "html":
        return generate_html_report(integrated_data)
    else:
        return f"不支持的格式: {format}"

def generate_markdown_report(data: dict) -> str:
    """生成Markdown格式报告"""
    ticker = data.get("ticker", "UNKNOWN")
    summary = data.get("summary", "")
    
    report = f"""# 投资分析报告 - {ticker}

## 📊 分析摘要
{summary}

## 📈 详细分析

### 宏观分析
{format_macro_analysis(data.get('detailed_analysis', {}).get('macro_analysis', {}))}

### 基本面分析
{format_research_analysis(data.get('detailed_analysis', {}).get('research_analysis', {}))}

### 技术分析
{format_trading_analysis(data.get('detailed_analysis', {}).get('trading_analysis', {}))}

### 风险监控
{format_executor_analysis(data.get('detailed_analysis', {}).get('executor_analysis', {}))}

## 🎯 投资建议
{format_recommendations(data.get('recommendations', []))}

## ⚠️ 风险提示
{format_risk_assessment(data.get('risk_assessment', {}))}

## 📋 报告信息
- 生成时间: {data.get('timestamp', '未知')}
- 分析类型: {data.get('analysis_type', '完整分析')}
- 信心度: {data.get('confidence_score', 0.5) * 100:.1f}%
- 处理时间: {data.get('metadata', {}).get('processing_time', 0):.2f}秒

---
*本报告由多智能体股市监测系统生成，仅供参考。投资有风险，决策需谨慎。*
"""
    return report

def format_macro_analysis(macro: dict) -> str:
    """格式化宏观分析"""
    if not macro:
        return "无宏观分析数据"
    
    lines = []
    if "recommendation" in macro:
        lines.append(f"- **建议**: {macro['recommendation']}")
    if "market_condition" in macro:
        lines.append(f"- **市场状况**: {macro['market_condition']}")
    if "risk_level" in macro:
        lines.append(f"- **风险等级**: {macro['risk_level']}")
    if "key_indicators" in macro:
        indicators = macro['key_indicators']
        lines.append(f"- **关键指标**: S&P500: {indicators.get('sp500_change', 0):+.2f}%, "
                    f"NASDAQ: {indicators.get('nasdaq_change', 0):+.2f}%")
    
    return "\n".join(lines)

def format_research_analysis(research: dict) -> str:
    """格式化基本面分析"""
    if not research:
        return "无基本面分析数据"
    
    lines = []
    if "company_name" in research:
        lines.append(f"- **公司**: {research['company_name']}")
    if "recommendation" in research:
        lines.append(f"- **建议**: {research['recommendation']}")
    if "fundamental_score" in research:
        lines.append(f"- **基本面评分**: {research['fundamental_score']:.1f}/100")
    if "financial_ratios" in research:
        ratios = research['financial_ratios']
        lines.append(f"- **财务比率**: 净利率: {ratios.get('net_margin', 0):.1f}%, "
                    f"ROE: {ratios.get('roe', 0):.1f}%, "
                    f"PE: {ratios.get('pe_ratio', 0):.1f}")
    
    return "\n".join(lines)

def format_trading_analysis(trading: dict) -> str:
    """格式化技术分析"""
    if not trading:
        return "无技术分析数据"
    
    lines = []
    if "trading_recommendation" in trading:
        lines.append(f"- **交易建议**: {trading['trading_recommendation']}")
    if "current_price" in trading:
        lines.append(f"- **当前价格**: ${trading['current_price']:.2f}")
    if "confidence" in trading:
        lines.append(f"- **信心度**: {trading['confidence'] * 100:.1f}%")
    if "technical_signals" in trading:
        signals = trading['technical_signals']
        if "error" not in signals:
            lines.append(f"- **技术信号**: MA5: ${signals.get('ma5', 0):.2f}, "
                        f"MA10: ${signals.get('ma10', 0):.2f}, "
                        f"趋势: {signals.get('trend', 'unknown')}")
    
    return "\n".join(lines)

def format_executor_analysis(executor: dict) -> str:
    """格式化执行监控分析"""
    if not executor:
        return "无风险监控数据"
    
    lines = []
    if "risk_assessment" in executor:
        risk = executor['risk_assessment']
        lines.append(f"- **总体风险**: {risk.get('risk_level', '未知')}")
        lines.append(f"- **风险评分**: {risk.get('overall_risk', 0) * 100:.1f}%")
        if "recommendations" in risk:
            lines.append("- **风险控制建议**:")
            for rec in risk['recommendations'][:3]:
                lines.append(f"  - {rec}")
    
    return "\n".join(lines)

def format_recommendations(recommendations: list) -> str:
    """格式化建议列表"""
    if not recommendations:
        return "无具体建议"
    
    lines = []
    for i, rec in enumerate(recommendations, 1):
        lines.append(f"{i}. **{rec.get('type', '建议')}**: {rec.get('content', '')}")
    
    return "\n".join(lines)

def format_risk_assessment(risk: dict) -> str:
    """格式化风险评估"""
    if not risk:
        return "无风险评估数据"
    
    lines = []
    lines.append(f"- **风险等级**: {risk.get('risk_level', '未知')}")
    lines.append(f"- **风险评分**: {risk.get('overall_risk', 0) * 100:.1f}%")
    
    if "monitoring_points" in risk:
        lines.append("- **监控要点**:")
        for point in risk['monitoring_points']:
            lines.append(f"  - {point}")
    
    return "\n".join(lines)
```

## 工作流示例
1. 用户输入："分析AAPL的投资机会"
2. Orchestrator 解析请求，识别需要分析AAPL
3. 调用 Macro Agent 分析市场环境
4. 调用 Research Agent 分析AAPL财务数据
5. 调用 Trading Agent 制定交易策略
6. 调用 Executor Agent 评估执行风险
7. 整合所有结果，生成最终报告

## 输入输出规范
- **输入**: 用户查询字符串，可选分析类型参数
- **输出**: 结构化分析报告，支持多种格式
- **错误处理**: 智能体故障时的降级策略
- **性能要求**: 完整分析应在2分钟内完成

## 配置参数
```yaml
orchestrator:
  default_analysis_type: "full"
  timeout_seconds: 300
  retry_attempts: 3
  cache_enabled: true
  cache_ttl: 3600  # 1小时