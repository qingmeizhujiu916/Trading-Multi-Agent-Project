@echo off
echo ========================================
echo 多智能体股市监测系统 - 完整启动脚本
echo 包含数据获取和系统启动
echo ========================================
echo.

REM 检查Python是否安装
python --version >nul 2>&1
if errorlevel 1 (
    echo 错误: 未找到Python，请先安装Python 3.8+
    pause
    exit /b 1
)

REM 检查依赖是否安装
echo 检查Python依赖...
pip list | findstr "fastapi" >nul
if errorlevel 1 (
    echo 安装依赖...
    pip install -r requirements.txt
    pip install requests pandas
) else (
    echo 依赖已安装
)

REM 创建必要的目录
echo 创建必要的目录...
if not exist "logs" mkdir logs
if not exist "data" mkdir data

echo.
echo ========================================
echo 数据获取选项
echo ========================================
echo.
echo 请选择数据获取方式:
echo 1. 使用现有数据（不更新）
echo 2. 生成新的测试数据
echo 3. 尝试从网络获取真实数据（需要网络连接）
echo.
set /p choice="请输入选项 (1-3): "

if "%choice%"=="1" (
    echo 使用现有数据...
    goto :start_system
) else if "%choice%"=="2" (
    echo 生成测试数据...
    python data_fetcher.py --mode test
    goto :start_system
) else if "%choice%"=="3" (
    echo 尝试获取真实数据...
    python data_fetcher.py --mode test --real-api
    goto :start_system
) else (
    echo 无效选项，使用现有数据
    goto :start_system
)

:start_system
echo.
echo ========================================
echo 启动API服务器...
echo API地址: http://localhost:8000
echo 文档地址: http://localhost:8000/docs
echo ========================================
echo.

REM 启动API服务器
start cmd /k "python api_server.py"

echo.
echo ========================================
echo 启动前端页面...
echo 前端地址: file:///%CD%/frontend/index.html
echo ========================================
echo.

REM 等待API服务器启动
echo 等待API服务器启动...
timeout /t 5 /nobreak >nul

REM 打开前端页面
start "" "frontend\index.html"

echo.
echo ========================================
echo 系统已启动！
echo ========================================
echo.
echo 请访问:
echo 1. API服务器: http://localhost:8000
echo 2. API文档: http://localhost:8000/docs
echo 3. 前端页面: file:///%CD%/frontend/index.html
echo.
echo 测试系统功能:
echo python test_api.py
echo.
echo 按任意键退出...
pause >nul