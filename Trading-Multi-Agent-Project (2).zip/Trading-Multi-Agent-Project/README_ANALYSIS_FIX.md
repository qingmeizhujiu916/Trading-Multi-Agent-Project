# 多智能体股市监测系统 - 分析功能完善

## 问题描述
原项目的分析按键无法进行实际的分析，只是弹出简单的alert提示。

## 解决方案
已完善分析功能，实现了以下改进：

### 1. 后端API服务器 (`api_server.py`)
- 基于FastAPI构建RESTful API
- 集成DeepSeek AI API进行智能分析
- 实现五个智能体的协作分析：
  - **宏观分析智能体**: 分析市场整体趋势
  - **个股研究智能体**: 分析公司财务状况
  - **交易策略智能体**: 分析技术面和交易信号
  - **执行监控智能体**: 评估执行风险
  - **总指挥智能体**: 协调所有智能体工作流

### 2. 前端改进 (`frontend/index.html`)
- 分析按钮现在调用后端API进行实际分析
- 支持两种分析模式：
  - **完整分析**: 使用所有智能体进行全面分析
  - **快速分析**: 仅使用研究和交易智能体
- 实时显示分析结果，包括：
  - 综合评分和风险等级
  - 各智能体的详细分析结果
  - AI生成的建议和风险提示

### 3. DeepSeek API集成
- 使用API密钥: `sk-4e12ef8835d94ee0bfb79097eb9481d1`
- 每个智能体都可以调用DeepSeek API进行AI增强分析
- 支持传统分析和AI分析两种模式

## 系统架构

```
多智能体股市监测系统
├── 前端 (HTML/CSS/JavaScript)
│   ├── 用户界面
│   ├── 图表展示
│   └── API调用
├── 后端API服务器 (FastAPI)
│   ├── RESTful API接口
│   ├── 智能体协作引擎
│   └── DeepSeek AI集成
├── 数据层
│   ├── 公司财务数据 (JSON)
│   ├── 市场概况数据 (JSON)
│   └── 价格历史数据 (JSON)
└── 智能体系统
    ├── 宏观分析智能体
    ├── 个股研究智能体
    ├── 交易策略智能体
    ├── 执行监控智能体
    └── 总指挥智能体
```

## 安装和运行

### 方法1: 使用启动脚本 (推荐)
```bash
# Windows
start_system.bat

# 或手动运行
python api_server.py
# 然后打开 frontend/index.html
```

### 方法2: 手动安装和运行
```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 创建必要目录
mkdir logs
mkdir data

# 3. 启动API服务器
python api_server.py

# 4. 打开前端页面
# 在浏览器中打开 frontend/index.html
```

## API接口

### 基础接口
- `GET /` - 系统状态
- `GET /status` - 智能体状态
- `GET /companies` - 可分析的公司列表
- `GET /market/overview` - 市场概况

### 分析接口
- `GET /analyze/{ticker}` - 分析指定公司
  - 参数: `analysis_type` (full/quick)
  - 参数: `use_ai` (true/false)
- `POST /analyze` - 分析公司 (JSON请求体)

### API文档
启动服务器后访问: http://localhost:8000/docs

## 使用示例

### 1. 快速分析AAPL
```bash
curl "http://localhost:8000/analyze/AAPL?analysis_type=quick&use_ai=true"
```

### 2. 完整分析TSLA
```bash
curl "http://localhost:8000/analyze/TSLA?analysis_type=full&use_ai=true"
```

### 3. 获取公司列表
```bash
curl "http://localhost:8000/companies"
```

## 前端使用说明

1. **选择公司**: 点击公司卡片或输入公司代码
2. **选择分析模式**:
   - **开始分析**: 完整分析 (所有智能体参与)
   - **快速分析**: 仅基本面和技术面分析
3. **查看结果**: 分析结果会显示在五个标签页中
   - 宏观分析: 市场环境评估
   - 财务分析: 公司财务状况
   - 技术分析: 交易信号和建议
   - 风险监控: 执行风险评估
   - 综合建议: 总体投资建议

## 测试系统

运行测试脚本验证系统功能:
```bash
python test_api.py
```

## 数据文件

系统使用以下JSON数据文件:
- `data/company_financials.json` - 公司财务数据
- `data/market_overview.json` - 市场概况数据
- `data/price_history.json` - 价格历史数据

## 技术特点

1. **AI增强分析**: 集成DeepSeek AI进行智能分析
2. **多智能体协作**: 五个专业智能体分工协作
3. **实时反馈**: 前端实时显示分析进度和结果
4. **模块化设计**: 易于扩展和维护
5. **RESTful API**: 标准化的API接口

## 故障排除

### 常见问题

1. **API服务器无法启动**
   - 检查Python和依赖是否安装
   - 检查端口8000是否被占用

2. **前端无法连接到API**
   - 确保API服务器正在运行
   - 检查浏览器控制台是否有CORS错误

3. **分析结果为空**
   - 检查数据文件是否存在
   - 检查DeepSeek API密钥是否有效

4. **AI分析失败**
   - 检查网络连接
   - 检查API调用频率限制

### 日志文件
- `logs/api_server.log` - API服务器日志
- `logs/system.log` - 系统日志

## 扩展和定制

### 添加新的智能体
1. 在`api_server.py`中创建新的智能体类
2. 在`Orchestrator`类中集成新智能体
3. 更新前端显示新智能体的分析结果

### 添加新的数据源
1. 在`DataLoader`类中添加数据加载方法
2. 创建相应的数据文件
3. 更新智能体使用新数据

### 自定义分析逻辑
1. 修改各个智能体的`analyze`方法
2. 调整AI提示词模板
3. 自定义评分算法和风险评估逻辑

## 注意事项

1. **投资风险**: 本系统仅供学习和研究使用，投资有风险
2. **API限制**: DeepSeek API有调用频率限制
3. **数据准确性**: 确保数据文件的准确性和时效性
4. **安全性**: 不要在生产环境中暴露API密钥

## 贡献

欢迎提交问题和改进建议！

## 许可证

仅供学习和研究使用。